<?php
return [
    'PAGE_SIZE'=>20,
];
