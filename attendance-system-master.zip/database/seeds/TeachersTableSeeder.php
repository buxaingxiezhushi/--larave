<?php

use Illuminate\Database\Seeder;

class TeachersTableSeeder extends Seeder
{
    /**
     * Run the database seeds.
     *
     * @return void
     */
    public function run()
    {
        DB::table('teachers')->insert([
            'id'=>'1',
            'staff_id'=>'2021082901',
            'created_at'=>now(),
            'updated_at'=>now(),
            'status'=>true,
            'join_date'=>'2021-08-29',
            'leave_date'=>'2038-01-01',
            ]);

        DB::table('teachers')->insert([
            'id'=>'2',
            'staff_id'=>'2023080101',
            'created_at'=>now(),
            'updated_at'=>now(),
            'status'=>true,
            'join_date'=>'2023-08-01',
            'leave_date'=>'2038-01-01',
            ]);

        DB::table('teachers')->insert([
            'id'=>'3',
            'staff_id'=>'2022090101',
            'created_at'=>now(),
            'updated_at'=>now(),
            'status'=>true,
            'join_date'=>'2022-09-01',
            'leave_date'=>'2038-01-01',
            ]);

        DB::table('teachers')->insert([
            'id'=>'4',
            'staff_id'=>'2023070102',
            'created_at'=>now(),
            'updated_at'=>now(),
            'status'=>true,
            'join_date'=>'2023-07-01',
            'leave_date'=>'2038-01-01',
            ]);

        DB::table('teachers')->insert([
            'id'=>'5',
            'staff_id'=>'2023010101',
            'created_at'=>now(),
            'updated_at'=>now(),
            'status'=>true,
            'join_date'=>'2023-01-01',
            'leave_date'=>'2038-01-01',
            ]);

        DB::table('teachers')->insert([
            'id'=>'6',
            'staff_id'=>'2023092001',
            'created_at'=>now(),
            'updated_at'=>now(),
            'status'=>true,
            'join_date'=>'2023-09-20',
            'leave_date'=>'2038-01-01',
            ]);

        DB::table('teachers')->insert([
            'id'=>'7',
            'staff_id'=>'2024021801',
            'created_at'=>now(),
            'updated_at'=>now(),
            'status'=>true,
            'join_date'=>'2024-02-18',
            'leave_date'=>'2038-01-01',
            ]);

        DB::table('teachers')->insert([
            'id'=>'8',
            'staff_id'=>'2024021802',
            'created_at'=>now(),
            'updated_at'=>now(),
            'status'=>true,
            'join_date'=>'2024-02-18',
            'leave_date'=>'2038-01-01',
            ]);

        DB::table('teachers')->insert([
            'id'=>'9',
            'staff_id'=>'2024022201',
            'created_at'=>now(),
            'updated_at'=>now(),
            'status'=>true,
            'join_date'=>'2024-02-22',
            'leave_date'=>'2038-01-01',
            ]);


    }
}
