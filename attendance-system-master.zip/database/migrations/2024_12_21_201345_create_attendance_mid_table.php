<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class CreateAttendanceMidTable extends Migration
{
    public function up()
    {
        Schema::create('attendance_mid_table', function (Blueprint $table) {
            // 使用 increments() 创建自增的主键
            $table->increments('id');

            // staff_id 列，unsigned integer
            $table->unsignedInteger('staff_id')->nullable()->default(null);

            // year 列，unsigned integer
            $table->unsignedInteger('year')->nullable()->default(null);

            // month 列，unsigned integer
            $table->unsignedInteger('month')->nullable()->default(null);

            // 时间戳
            $table->timestamps();
        });
    }

    public function down()
    {
        Schema::dropIfExists('attendance_mid_table');
    }
}
