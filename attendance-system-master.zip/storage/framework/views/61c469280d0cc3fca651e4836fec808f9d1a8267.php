<?php $__env->startSection('title','编辑课程'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('shared._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('lessons.update',array($lesson->id,'term_id'=>$current_term_id))); ?>" method="POST" class="definewidth m20">
<table class="table table-bordered table-hover definewidth m10">
  <?php echo e(method_field('PATCH')); ?>

  <?php echo e(csrf_field()); ?>

    <tr>
        <td class="tableleft">课程名称*</td>
         <td>
          <input type="text" name="lesson_name" value="<?php echo e($lesson->lesson_name); ?>">
        </td>
    </tr>
    <tr>
        <td class="tableleft">课程时间</td>
        <td>
          <input type="time" name="lesson_start_time" value="<?php echo e($lesson->start_time); ?>"/>&nbsp;&nbsp;至&nbsp;&nbsp;
          <input type="time" name="lesson_end_time" value="<?php echo e($lesson->end_time); ?>"/>
          <br>
          <?php if(!$flag): ?>
            <select name="day" id="day">
              <option value="">请选择星期...</option>
              <?php $__currentLoopData = $days; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <option value="<?php echo e($d); ?>"
              <?php if($lesson->day == $d): ?>
              selected
              <?php endif; ?>
              ><?php echo e($d); ?></option>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          <?php else: ?>
          <select name="day" id="day">
            <option value="All">Mon, Wed, Fri</option>
          </select>
          <?php endif; ?>
        </td>
    </tr>
    <tr>
        <td class="tableleft">教室*</td>
         <td>
          <input type="text" name="classroom" value="<?php echo e($lesson->classroom); ?>">
        </td>
    </tr>
    <tr>
        <td class="tableleft">上课学期*</td>
        <td>
          <?php echo e($lesson->term->term_name); ?>

        </td>
    </tr>
    <?php if($lesson->teacher_id == null): ?>
    <tr>
        <td width="10%" class="tableleft">上课老师</td>
        <td>
          暂无
        </td>
    </tr>
    <tr>
        <td class="tableleft">生效日期*</td>
         <td>
          <input type="date" name="effective_date" value="<?php echo e($lesson->term->start_date); ?>">
        </td>
    </tr>
    <?php else: ?>
    <tr>
      <td width="10%" class="tableleft">上课老师</td>
      <td>
        <?php echo e($lesson->teacher->staff->englishname); ?>

      </td>
    </tr>
    <tr>
        <td class="tableleft">生效日期*</td>
         <td>
          <input type="date" name="effective_date" value="<?php echo e(date('Y-m-d')); ?>">
        </td>
    </tr>
    <?php endif; ?>
    <?php if(count($lesson->lessonUpdates) > 1): ?>
    <tr>
      <td width="10%" class="tableleft">历史记录</td>
      <td>
        <?php $__currentLoopData = $lesson->lessonUpdates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$lu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <?php if($key != count($lesson->lessonUpdates)-1): ?>
          星期:<?php echo e($lu->day); ?>&nbsp;时长:<?php echo e($lu->duration); ?>&nbsp;有效日期:<?php echo e($lu->start_date); ?>~<?php echo e($lu->end_date); ?><br>
          <?php endif; ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </td>
    </tr>
    <?php endif; ?>
    <tr>
        <td class="tableleft"></td>
        <td>
            <button type="submit" class="btn btn-primary" type="button">提交</button> &nbsp;&nbsp;<a class="btn btn-success" href="<?php echo e(route('lessons.index',array('term_id'=>$current_term_id))); ?>" role="button">返回课程管理</a>
        </td>
    </tr>
</table>
</form>
</div>

<script>
  $(function(){
      $('#name_select').chosen();
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/lessons/edit.blade.php ENDPATH**/ ?>