<?php $__env->startSection('title','新增代课'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('shared._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('substitutes.store',array('current_term_id'=>$current_term_id))); ?>" method="POST" class="definewidth m20">
<table class="table table-bordered table-hover definewidth m10">
  <?php echo e(csrf_field()); ?>

    <tr>
      <td class="tableleft">当前学期</td>
      <td>
        <input type="text" name="term_name" value="<?php echo e($term->term_name); ?>" disabled="">
      </td>
    </tr>
    <tr>
        <td class="tableleft">课程名称*</td>
        <td>
          <select name="lesson_id" id="lesson_select">
            <option value=""> 选择课程... </option>
            <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($l->id); ?>"
              <?php if(old('lesson_id') == $l->id): ?>
                selected
              <?php endif; ?>
            >
              <?php echo e($l->teacher->staff->englishname); ?>&nbsp;
              <?php echo e($l->lesson_name); ?>&nbsp;
              <?php echo e($l->day); ?>-<?php echo e(date('H:i',strtotime($l->start_time))); ?>-<?php echo e(date('H:i',strtotime($l->end_time))); ?>-<?php echo e($l->classroom); ?>

            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </td>
    </tr>
    <tr>
        <td width="10%" class="tableleft">代课老师</td>
        <td>
        <select name="substitute_teacher_id" id="substitute_name_select">
          <option value=""> 选择代课老师... </option>
          <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
          <option value="<?php echo e($t->id); ?>"
            <?php if(old('substitute_teacher_id') == $t->id): ?>
              selected
            <?php endif; ?>
          ><?php echo e($t->staff->englishname); ?></option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </td>
    </tr>
    <tr>
      <td width="10%" class="tableleft">上课日期*</td>
      <td>
        <input type="date" name="lesson_date" value="<?php echo e(old('lesson_date')); ?>">
      </td>
    </tr>
    <tr>
        <td class="tableleft"></td>
        <td>
            <button type="submit" class="btn btn-primary" type="button">提交</button> &nbsp;&nbsp;<a class="btn btn-success" href="<?php echo e(route('substitutes.index', array('term_id'=>$current_term_id))); ?>" role="button">返回代课管理</a>
        </td>
    </tr>
</table>
</form>
</div>

<script>
  $(function(){
    $('#lesson_select').chosen();
    $('#origin_name_select').chosen();
    $('#substitute_name_select').chosen();
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/substitutes/create.blade.php ENDPATH**/ ?>