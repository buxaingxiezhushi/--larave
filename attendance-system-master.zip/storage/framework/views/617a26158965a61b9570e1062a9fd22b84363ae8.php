<?php $__env->startSection('title','编辑员工'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
<?php echo $__env->make('shared._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('staffs.update_work_time', $staff->id)); ?>" method="post" class="definewidth m20">
  <?php echo e(method_field('PATCH')); ?>

  <?php echo e(csrf_field()); ?>

  <table class="table table-bordered table-hover definewidth m10">
      <tr>
          <td width="10%" class="tableleft">员工姓名</td>
          <td><?php echo e($staff->staffname); ?></td>
      </tr>
      <tr>
          <td class="tableleft">英文名</td>
          <td><?php echo e($staff->englishname); ?></td>
      </tr>
      <tr>
          <td class="tableleft">员工编号*</td>
          <td><?php echo e($staff->id); ?></td>
      </tr>
      <tr>
          <td class="tableleft">所属部门</td>
           <td>
            <?php echo e($staff->department_name); ?>

          </td>
      </tr>
      <tr>
          <td class="tableleft">当前职位*</td>
           <td>
            <?php echo e($staff->position_name); ?>

          </td>
      </tr>
      <tr>
          <td class="tableleft">应上下班时间*</td>
          <td>
            <?php for($i=0;$i<=6;$i++): ?>
            周<?php echo e($days[$i]); ?>：
              <input type="time" name="work_time[<?php echo e($i); ?>]" value="<?php echo e($workdays[$i]->work_time); ?>"/>
             &nbsp;至&nbsp;
             <input type="time" name="home_time[<?php echo e($i); ?>]" value="<?php echo e($workdays[$i]->home_time); ?>"/> <br>
            <?php endfor; ?>
          </td>
      </tr>
      <tr>
          <td class="tableleft">生效日期*</td>
           <td>
            <input type="date" name="effective_date" value="old('effective_date')">
          </td>
      </tr>

      <tr>
          <td class="tableleft"></td>
          <td>
              <button type="submit" class="btn btn-primary" type="button" onclick="sure()">提交</button> &nbsp;&nbsp;
              <?php if($staff_id != null): ?>
              <a class="btn btn-success" href="<?php echo e(route('staffs.part_time_index')); ?>" role="button">返回列表</a>
              <?php else: ?>
              <a class="btn btn-success" href="<?php echo e(route('staffs.index')); ?>" role="button">返回列表</a>
              <?php endif; ?>
          </td>
      </tr>
  </table>
</form>

</div>



<script>
  var defaultDate = document.querySelectorAll('#date-picker');
  for (var i = 0; i<defaultDate.length; i++) {
    defaultDate[i].valueAsDate = new Date();
  }

  function sure() {
      if (!confirm("提交后该段时间的排班记录不可更改，时间是否无误？")) {
          window.event.returnValue = false;
      }
  }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/staffs/edit_work_time.blade.php ENDPATH**/ ?>