<?php $__env->startSection('title','关联课程'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
<?php echo $__env->make('shared._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('teachers.update',array($teacher->id,'term_id'=>$current_term_id))); ?>" method="post" class="definewidth m20">
  <?php echo e(method_field('PATCH')); ?>

  <?php echo e(csrf_field()); ?>

  <table class="table table-bordered table-hover definewidth m10">
      <tr>
        <td width="10%" class="tableleft">学期</td>
        <td>
          <span style="font-weight: bold;"><?php echo e($term->term_name); ?></span>
        </td>
      </tr>
      <tr>
          <td width="10%" class="tableleft">英文名</td>
          <td>
            <select name="teacher_id" id="">
              <option value="<?php echo e($teacher->id); ?>" selected><?php echo e($teacher->staff->englishname); ?></option>
            </select>
          </td>
      </tr>
      <tr>
        <td width="10%" class="tableleft">已上课程</td>
        <td>
          <?php if(count($teacher->lessons) != 0): ?>
            <?php $__currentLoopData = $teacher->lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php if($l->term_id == $current_term_id): ?>
                <?php if($flag): ?>
                  <?php if($l->day == 'Mon'): ?>
                  <?php echo e($l->lesson_name); ?>&nbsp;
                  <?php echo e(date('H:i',strtotime($l->start_time))); ?>-<?php echo e(date('H:i',strtotime($l->end_time))); ?>-<?php echo e($l->classroom); ?>

                  <?php endif; ?>
                <?php else: ?>
                <?php echo e($l->lesson_name); ?>&nbsp;
                <?php echo e($l->day); ?>-<?php echo e(date('H:i',strtotime($l->start_time))); ?>-<?php echo e(date('H:i',strtotime($l->end_time))); ?>-<?php echo e($l->classroom); ?>

                <br>
                <?php endif; ?>
              <?php endif; ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          <?php else: ?>
          暂无
          <?php endif; ?>
        </td>
      </tr>
      <tr>
          <td width="10%" class="tableleft">选择课程</td>
          <td>
          <select data-placeholder="选择课程..." id="chosen-select" name="lesson_id[]" multiple>
            <option value=""></option>
            <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($l->id); ?>">
              <?php if($flag): ?>
              <?php echo e($l->lesson_name); ?>&nbsp;
              <?php echo e(date('H:i',strtotime($l->start_time))); ?>-<?php echo e(date('H:i',strtotime($l->end_time))); ?>-<?php echo e($l->classroom); ?>

              <?php else: ?>
              <?php echo e($l->lesson_name); ?>&nbsp;
              <?php echo e($l->day); ?>-<?php echo e(date('H:i',strtotime($l->start_time))); ?>-<?php echo e(date('H:i',strtotime($l->end_time))); ?>-<?php echo e($l->classroom); ?>

              <?php endif; ?>
            </option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
          </td>
      </tr>
      <tr>
          <td class="tableleft"></td>
          <td>
              <button type="submit" class="btn btn-primary" type="button">提交</button> &nbsp;&nbsp;<a class="btn btn-success" href="<?php echo e(route('teachers.index',array('term_id'=>$current_term_id))); ?>" role="button">返回列表</a>
          </td>
      </tr>
  </table>
</form>

</div>
<script>
  $(function(){
      $('#chosen-select').chosen({no_results_text: "Oops, nothing found!"});
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/teachers/edit.blade.php ENDPATH**/ ?>