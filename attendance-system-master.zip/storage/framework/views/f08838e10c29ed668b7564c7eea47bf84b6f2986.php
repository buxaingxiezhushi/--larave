<?php $__env->startSection('title','课程信息'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form class="form-inline definewidth m20" action="" method="GET">
    课程名称
    <input type="text" name="lesson_name" id="lesson_name"class="abc input-default" placeholder="" value="<?php echo e(old('lesson_name')); ?>">&nbsp;&nbsp;
    <button type="submit" class="btn btn-primary">查询</button>
    &nbsp;&nbsp;
    <a class="btn btn-success" href="<?php echo e(route('lessons.create',array('term_id'=>$term_id))); ?>" role="button">新增课程</a>
</form>

<form class="form-inline definewidth m20" action="<?php echo e(route('lessons.index')); ?>" method="GET">
    当前学期
    <select name="term_id" id="term_id">
      <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($term->id); ?>"
      <?php if($term_id == $term->id): ?>
      selected
      <?php endif; ?>
      ><?php echo e($term->term_name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>&nbsp;&nbsp;&nbsp;
    <button type="submit" class="btn btn-primary">选择学期</button>
</form>
<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>课程名称</th>
        <th>上课时间</th>
        <th>教室</th>
        <th>学期</th>
        <th>时长</th>
        <th>上课老师</th>
        <th>操作</th>
    </tr>
    </thead>
    <?php if(count($lessons) != 0): ?>
    <tbody id="pageInfo">
      <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
            <td><?php echo e($l->lesson_name); ?></td>
            <?php if($l->day == 'Mon'): ?>
            <td><?php echo e(date('H:i',strtotime($l->start_time))); ?>-<?php echo e(date('H:i',strtotime($l->end_time))); ?></td>
            <?php else: ?>
            <td><?php echo e($l->day); ?>-<?php echo e(date('H:i',strtotime($l->start_time))); ?>-<?php echo e(date('H:i',strtotime($l->end_time))); ?></td>
            <?php endif; ?>
            <td><?php echo e($l->classroom); ?></td>
            <td><?php echo e($l->term->term_name); ?></td>
            <td><?php echo e($l->duration); ?></td>
            <?php if($l->teacher!=null): ?>
            <td><?php echo e($l->teacher->staff->englishname); ?></td>
            <?php else: ?>
            <td></td>
            <?php endif; ?>
            <td>
                <a href="<?php echo e(route('lessons.edit',array($l->id, 'term_id'=>$term_id))); ?>" class="btn btn-primary">编辑课程</a>
                <?php if($l->teacher_id != null): ?>
                <a href="<?php echo e(route('lessons.edit_teacher',array($l->id, 'term_id'=>$term_id))); ?>" class="btn btn-info">更换老师</a>
                <?php else: ?>
                <a href="" class="btn btn-info" disabled>更换老师</a>
                <?php endif; ?>
                <form action="<?php echo e(route('lessons.destroy',array($l->id, 'term_id'=>$term_id))); ?>" method="POST" style="display: inline-block;">
                  <?php echo e(method_field('DELETE')); ?>

                  <?php echo e(csrf_field()); ?>

                  <?php if(count($l->substitutes) != 0 || count($l->alters) != 0): ?>
                  <button type="submit" class="btn btn-warning" type="button" onclick="delcfm();" disabled="">删除</button>
                  <?php else: ?>
                  <button type="submit" class="btn btn-warning" type="button" onclick="delcfm();">删除</button>
                  <?php endif; ?>

                </form>
            </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
</table>
<?php echo $__env->make('shared._nothing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if(count($lessons)>config('page.PAGE_SIZE')): ?>
<?php echo $__env->make('shared._pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<script>
  function delcfm() {
      if (!confirm("确认操作？")) {
          window.event.returnValue = false;
      }
  }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/lessons/index.blade.php ENDPATH**/ ?>