<?php $__env->startSection('title','编辑加班'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
<?php echo $__env->make('shared._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('extra_works.update',$extra_work->id)); ?>" method="post" class="definewidth m20">
  <?php echo e(method_field('PATCH')); ?>

  <?php echo e(csrf_field()); ?>

<table class="table table-bordered table-hover definewidth m10">
    <tr>
        <td width="10%" class="tableleft">员工英文名</td>
        <td>
          <input type="text" value="<?php echo e($staff->englishname); ?>" disabled>
        </td>
    </tr>

    <tr>
        <td class="tableleft">加班类型</td>
         <td>
          <input type="text" value="<?php echo e($extra_work->extra_work_type); ?>" disabled>
        </td>
    </tr>


    <tr>
        <td class="tableleft">加班时间*</td>
        <td>
          <input type="datetime-local" name="extra_work_start_time" value="<?php echo e(date('Y-m-d',strtotime($extra_work->extra_work_start_time)).'T'.date('H:i',strtotime($extra_work->extra_work_start_time))); ?>"
          /> &nbsp;至&nbsp;
          <input type="datetime-local" name="extra_work_end_time"
          value="<?php echo e(date('Y-m-d',strtotime($extra_work->extra_work_end_time)).'T'.date('H:i',strtotime($extra_work->extra_work_end_time))); ?>"
          />
        </td>
    </tr>
    <tr>
        <td class="tableleft">是否批准*</td>
        <td>
          <select name="approve">
            <option value=""> -----请选择----- </option>
            <option value=1 <?php if($extra_work->approve == 1): ?> selected <?php endif; ?>>是</option><option value=0 <?php if($extra_work->approve == 0): ?> selected <?php endif; ?>>否</option>
          </select>
        </td>
    </tr>
    <tr>
        <td class="tableleft">备注*</td>
        <td>
          <?php if($extra_work->note!=null): ?>
          <textarea name="note" id="" rows="5"> <?php echo e($extra_work->note); ?> </textarea>
          <?php else: ?>
          <textarea name="note" id="" rows="5" placeholder="请填写修改原因"></textarea>
          <?php endif; ?>
        </td>
    </tr>
    <tr>
        <td class="tableleft"></td>
        <td>
            <button type="submit" class="btn btn-primary" type="button">提交</button> &nbsp;&nbsp;<a class="btn btn-success" href="<?php echo e(route('extra_works.index')); ?>" role="button">返回列表</a>
        </td>
    </tr>
</table>
</form>
</div>

<script>

  $(function(){
      $('#name_select').chosen();
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/extra_works/edit.blade.php ENDPATH**/ ?>