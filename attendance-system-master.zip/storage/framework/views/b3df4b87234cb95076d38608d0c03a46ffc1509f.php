<?php $__env->startSection('title','新增请假'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
<?php echo $__env->make('shared._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('absences.store')); ?>" method="post" class="definewidth m20">
  <?php echo e(csrf_field()); ?>

<table class="table table-bordered table-hover definewidth m10">
    <tr>
        <td width="10%" class="tableleft">员工英文名*</td>
        <?php if($staffs != null): ?>
        <td>
        <select name="staff_id" id="name_select">
          <option value=""> -----请选择----- </option>
          <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($staff->id); ?> " <?php if(old('staff_id') == $staff->id): ?> selected <?php endif; ?>> <?php echo e($staff->englishname); ?> </option>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </select>
        </td>
        <?php else: ?>
        <td>
          <select name="staff_id" id="name_select">
              <option value="<?php echo e($staff->id); ?>" selected> <?php echo e($staff->englishname); ?> </option>
          </select>
        </td>
        <?php endif; ?>
    </tr>

    <?php if($staffs == null): ?>
    <tr>
      <td class="tableleft">应工作</td>
      <?php if($attendance->should_work_time != null && $attendance->should_home_time != null): ?>
      <td>
        <?php echo e($attendance->should_work_time); ?>~<?php echo e($attendance->should_home_time); ?>&nbsp;时长:<?php echo e($attendance->should_duration); ?>

      </td>
      <?php else: ?>
      <td>无</td>
      <?php endif; ?>
    </tr>
    <tr>
      <td class="tableleft">实工作</td>
      <?php if($attendance->actual_work_time != null && $attendance->actual_home_time != null): ?>
      <td>
        <?php echo e($attendance->actual_work_time); ?>~<?php echo e($attendance->actual_home_time); ?>&nbsp;时长:<?php echo e($attendance->actual_duration); ?>

      </td>
      <?php else: ?>
      <td>无</td>
      <?php endif; ?>
    </tr>
    <?php endif; ?>

    <tr>
        <td class="tableleft">请假类型*</td>
         <td>
          <select name="absence_type">
            <option value=""> -----请选择----- </option>
            <option value="事假" <?php if(old('absence_type') == '事假'): ?> selected <?php endif; ?>>事假</option>
            <option value='年假' <?php if(old('absence_type') == '年假'): ?> selected <?php endif; ?>>年假</option>
            <option value='病假' <?php if(old('absence_type') == '病假'): ?> selected <?php endif; ?>>病假</option>
            <option value='调休' <?php if(old('absence_type') == '调休'): ?> selected <?php endif; ?>>调休</option>
          </select>
        </td>
    </tr>
    <tr>
        <td class="tableleft">请假时间*</td>
        <td>
          <?php if($staffs != null): ?>
          <input type="datetime-local" name="absence_start_time"
          <?php if(old('absence_start_time')!=null): ?> value="<?php echo e(date('Y-m-d',strtotime(old('absence_start_time'))).'T'.date('H:i',strtotime(old('absence_start_time')))); ?>"
          <?php endif; ?>
          /> &nbsp;至&nbsp;
          <input type="datetime-local" name="absence_end_time"
          <?php if(old('absence_end_time')!=null): ?> value="<?php echo e(date('Y-m-d',strtotime(old('absence_end_time'))).'T'.date('H:i',strtotime(old('absence_end_time')))); ?>"
          <?php endif; ?>
          />
          <?php else: ?>
            <?php if($attendance->should_duration !=null): ?>
            <input type="datetime-local" name="absence_start_time" value="<?php echo e(date('Y-m-d',strtotime($year.'-'.$month.'-'.$date)).'T'.$attendance->should_work_time); ?>"
            /> &nbsp;至&nbsp;
            <input type="datetime-local" name="absence_end_time" value="<?php echo e(date('Y-m-d',strtotime($year.'-'.$month.'-'.$date)).'T'.$attendance->should_home_time); ?>"
            />
            <?php else: ?>
            <input type="datetime-local" name="absence_start_time" value="<?php echo e(date('Y-m-d',strtotime($year.'-'.$month.'-'.$date)).'T00:00:00'); ?>"
            /> &nbsp;至&nbsp;
            <input type="datetime-local" name="absence_end_time" value="<?php echo e(date('Y-m-d',strtotime($year.'-'.$month.'-'.$date)).'T00:00:00'); ?>"
            />
            <?php endif; ?>
          <?php endif; ?>
        </td>
    </tr>
    <tr>
        <td class="tableleft">是否批准*</td>
        <td>
          <select name="approve">
            <option value=""> -----请选择----- </option>
            <option value=1 <?php if(old('approve') == 1): ?> selected <?php endif; ?>>是</option><option value=0 <?php if(old('approve') == 0): ?> selected <?php endif; ?>>否</option>
          </select>
        </td>
    </tr>
    <tr>
        <td class="tableleft">备注</td>
        <td>
          <textarea name="note" id="" rows="5" placeholder=""> <?php echo e(old('note')); ?> </textarea>
        </td>
    </tr>
    <tr>
        <td class="tableleft"></td>
        <td>
            <button type="submit" class="btn btn-primary" type="button">提交</button> &nbsp;&nbsp;
            <?php if($staffs != null): ?>
            <a class="btn btn-success" href="<?php echo e(route('absences.index')); ?>" role="button">返回列表</a>
            <?php else: ?>
            <a class="btn btn-success" href="<?php echo e(route('attendances.show',$total_attendance->id)); ?>" role="button">返回个人考勤</a>
            <?php endif; ?>
        </td>
    </tr>
</table>
</form>
</div>

<script>

  $(function(){
      $('#name_select').chosen();
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/absences/create.blade.php ENDPATH**/ ?>