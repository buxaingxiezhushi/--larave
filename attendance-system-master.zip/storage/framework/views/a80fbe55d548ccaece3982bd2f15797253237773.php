<?php $__env->startSection('title','调休信息'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form class="form-inline definewidth m20" action="" method="get">
<a class="btn btn-success" href="<?php echo e(route('holidays.create')); ?>" role="button">新增调休</a>
</form>
<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>日期</th>
        <th>类型</th>
        <th>调上班</th>
        <th>备注</th>
        <th>操作</th>
    </tr>
    </thead>
    <tbody id="pageInfo">
      <?php $__currentLoopData = $holidays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $h): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
            <td><?php echo e($h->date); ?></td>
            <td><?php echo e($h->holiday_type); ?></td>
            <?php if($h->workday_name != null): ?>
            <td><?php echo e($h->work_date); ?>,&nbsp;周<?php echo e($workdays[$h->workday_name]); ?></td>
            <?php else: ?>
            <td></td>
            <?php endif; ?>
            <td><?php echo e($h->note); ?></td>
            <td>
                <a href="<?php echo e(route('holidays.edit',$h->id)); ?>" class="btn btn-primary">编辑</a>
                <form action="<?php echo e(route('holidays.destroy', $h->id)); ?>" method="POST" style="display: inline-block;">
                  <?php echo e(method_field('DELETE')); ?>

                  <?php echo e(csrf_field()); ?>

                  <button type="submit" class="btn btn-danger" type="button" onclick="delcfm();">删除</button>
                </form>
            </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php if(count($holidays)>config('page.PAGE_SIZE')): ?>
<?php echo $__env->make('shared._pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<script>

  function delcfm() {
      if (!confirm("确认要删除？")) {
          window.event.returnValue = false;//这句话关键，没有的话，还是会执行下一步的
      }
  }

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/holidays/index.blade.php ENDPATH**/ ?>