<?php $__env->startSection('content'); ?>

<div class="login">
  <h1>刘少华教培机构的 <br> 考勤管理系统</h1>
  <?php echo $__env->make('shared._warnings', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
  <form method="POST" action="<?php echo e(route('login')); ?>">
    <?php echo e(csrf_field()); ?>

    <input type="text" name="name" placeholder="用户名" required="required" value="<?php echo e(old('name')); ?>"/>
    <input type="password" name="password" placeholder="密码" required="required" value="<?php echo e(old('password')); ?>"/>
    <button type="submit" class="btn btn-primary btn-block btn-large">登录</button>
  </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/sessions/create.blade.php ENDPATH**/ ?>