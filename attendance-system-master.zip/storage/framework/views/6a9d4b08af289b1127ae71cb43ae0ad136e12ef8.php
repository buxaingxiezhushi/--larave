<?php $__env->startSection('title','新增学期'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('shared._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('store_term')); ?>" method="POST" class="definewidth m20">
<table class="table table-bordered table-hover definewidth m10">
  <?php echo e(csrf_field()); ?>

    <tr>
      <td class="tableleft">学期名称*</td>
      <td>
        <input type="text" name="term_name" value="<?php echo e(old('term_name')); ?>">
        <br>
        <span style="color: gray;">如: 2023 Fall, 2024 Summer 1 ...</span>
      </td>
    </tr>
    <tr>
        <td width="10%" class="tableleft">学期开始日期*</td>
        <td>
          <input type="date" name="start_date" value="<?php echo e(old('start_date')); ?>">
        </td>
    </tr>
    <tr>
      <td width="10%" class="tableleft">学期结束日期*</td>
      <td>
        <input type="date" name="end_date" value="<?php echo e(old('end_date')); ?>">
      </td>
    </tr>
    <tr>
        <td class="tableleft"></td>
        <td>
            <button type="submit" class="btn btn-primary" type="button">提交</button> &nbsp;&nbsp;<a class="btn btn-success" href="<?php echo e(route('teachers.index', array('term_id'=>$term_id))); ?>" role="button">返回老师信息管理</a>
        </td>
    </tr>
</table>
</form>
</div>

<script>
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/teachers/create_term.blade.php ENDPATH**/ ?>