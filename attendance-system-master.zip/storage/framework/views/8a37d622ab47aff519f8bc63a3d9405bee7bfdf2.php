<?php $__env->startSection('title','代课信息'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form class="form-inline definewidth m20" action="" method="GET">
    课程名称
    <input type="text" name="lesson_name" id="lesson_name"class="abc input-default" placeholder="" value="<?php echo e(old('lesson_name')); ?>">&nbsp;&nbsp;
    <button type="submit" class="btn btn-primary">查询</button>
    &nbsp;&nbsp;
    <a class="btn btn-success" href="<?php echo e(route('substitutes.create',array('term_id'=>$term_id))); ?>" role="button">新增代课缺课</a>
</form>

<form class="form-inline definewidth m20" action="<?php echo e(route('substitutes.index')); ?>" method="GET">
    当前学期
    <select name="term_id" id="term_id">
      <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($term->id); ?>"
      <?php if($term_id == $term->id): ?>
      selected
      <?php endif; ?>
      ><?php echo e($term->term_name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>&nbsp;&nbsp;&nbsp;
    <button type="submit" class="btn btn-primary">选择学期</button>
</form>

<form action="<?php echo e(route('substitutes.export_sub', array('term_id'=>$term_id))); ?>" method="POST" style="margin-top: 15px; margin-left: 25px;">
  <?php echo e(csrf_field()); ?>

  开始日期&nbsp;<input type="date" name="start_date" value="old('start_date')">
  &nbsp;&nbsp;
  结束日期&nbsp;<input type="date" name="end_date" value="old('end_date')">
  &nbsp;&nbsp;
  <button type="submit" class="btn btn-success" type="button">导出代课缺课记录</button>
</form>

<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>课程名称</th>
        <th>上课时间</th>
        <th>教室</th>
        <th>学期</th>
        <th>时长</th>
        <th>原老师</th>
        <th>代课老师</th>
        <th>操作</th>
    </tr>
    </thead>
    <?php if(count($substitutes) != 0): ?>
    <tbody id="pageInfo">
      <?php $__currentLoopData = $substitutes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $s): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
            <td><?php echo e($s->lesson->lesson_name); ?></td>
            <td><?php echo e($s->lesson_date); ?>,&nbsp;<?php echo e($s->lesson->day); ?>-<?php echo e(date('H:i',strtotime($s->lesson->start_time))); ?>-<?php echo e(date('H:i',strtotime($s->lesson->end_time))); ?></td>
            <td><?php echo e($s->lesson->classroom); ?></td>
            <td><?php echo e($s->term->term_name); ?></td>
            <td><?php echo e($s->duration); ?></td>
            <td><?php echo e($s->teacher->staff->englishname); ?></td>
            <?php if($s->subTeacher != null): ?>
            <td><?php echo e($s->subTeacher->staff->englishname); ?></td>
            <?php else: ?>
            <td></td>
            <?php endif; ?>
            <td>
                <a href="<?php echo e(route('substitutes.edit',array($s->id,'term_id'=>$term_id))); ?>" class="btn btn-primary">编辑</a>
                <form action="<?php echo e(route('substitutes.destroy',array($s->id,'term_id'=>$term_id))); ?>" method="POST" style="display: inline-block;">
                  <?php echo e(method_field('DELETE')); ?>

                  <?php echo e(csrf_field()); ?>

                  <button type="submit" class="btn btn-warning" type="button" onclick="delcfm();">删除</button>
                </form>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
</table>
<?php echo $__env->make('shared._nothing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if(count($substitutes)>config('page.PAGE_SIZE')): ?>
<?php echo $__env->make('shared._pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<script>

  function delcfm() {
      if (!confirm("确认操作？")) {
          window.event.returnValue = false;
      }
  }

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/substitutes/index.blade.php ENDPATH**/ ?>