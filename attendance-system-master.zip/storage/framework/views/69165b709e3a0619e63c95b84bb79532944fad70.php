<?php $__env->startSection('content'); ?>

<div class="login">
  <h1>欢迎来到 <br> 刘少华的教培机构 <br> 考勤管理系统</h1>
  <form method="GET" action="<?php echo e(route('login')); ?>">
    <button type="submit" class="btn btn-primary btn-block btn-large">点击进入登录页</button>
  </form>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.template', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/welcome.blade.php ENDPATH**/ ?>