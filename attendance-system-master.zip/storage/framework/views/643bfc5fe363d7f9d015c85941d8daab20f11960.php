<?php $__env->startSection('title','老师信息'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form class="form-inline definewidth m20" action="<?php echo e(route('teachers.role')); ?>" method="POST">
  <?php echo e(csrf_field()); ?>

    英文姓名
    <select data-placeholder="选择员工..." class="chosen-select" name="staff_ids[]" id="select-staff" multiple>
      <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($staff->id); ?>"><?php echo e($staff->englishname); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
    &nbsp;&nbsp;
    <button type="submit" class="btn btn-success">新增老师</button>
    &nbsp;&nbsp;
    <!-- <a href="<?php echo e(route('leave_teachers.index')); ?>" class="btn btn-info">查看离职老师</a> -->
</form>

<form class="form-inline definewidth m20" action="<?php echo e(route('teachers.index')); ?>" method="GET">
    当前学期
    <select name="term_id" id="term_id">
      <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <option value="<?php echo e($term->id); ?>"
      <?php if($term_id == $term->id): ?>
      selected
      <?php endif; ?>
      ><?php echo e($term->term_name); ?></option>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>&nbsp;&nbsp;&nbsp;
    <button type="submit" class="btn btn-info">选择学期</button>
    &nbsp;&nbsp;
    <a class="btn btn-primary" href="<?php echo e(route('edit_term',array('term_id'=>$term_id))); ?>" role="button">修改当前学期</a>
    <!-- <a class="btn btn-primary" href="" role="button" disabled>修改当前学期</a> -->
    &nbsp;&nbsp;
    <a class="btn btn-success" href="<?php echo e(route('create_term',array('term_id'=>$term_id))); ?>" role="button">新增学期</a>
</form>
<?php if($term_id != null): ?>
<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>老师编号</th>
        <th>英文名</th>
        <th>本学期课程</th>
        <th>累计缺课时(学期)</th>
        <th>累计代课时(学期)</th>
        <th>操作</th>
    </tr>
    </thead>
    <?php if(count($teachers) != 0): ?>
    <tbody id="pageInfo">
        <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
            <td><?php echo e($t->staff->id); ?></td>
            <td><?php echo e($t->staff->englishname); ?></td>
            <td>
              <?php if(count($t->lessonUpdates) != 0): ?>
                <?php $__currentLoopData = $t->lessonUpdates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if($lu->lesson->term_id == $term_id): ?>
                  <?php if($flag): ?>
                    <?php if($lu->day == 'Mon'): ?>
                    <span style="font-weight: bold;"><?php echo e($lu->lesson->lesson_name); ?></span>
                    <?php endif; ?>
                  <?php else: ?>
                  <span style="font-weight: bold;"><?php echo e($lu->lesson->lesson_name); ?></span>
                  <?php endif; ?>

                <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php else: ?>
              无
              <?php endif; ?>
            </td>
            <td>
              <?php if($t->termTotals != null): ?>
                <?php $__currentLoopData = $t->termTotals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($tt->term_id == $term_id): ?>
                    <?php echo e($tt->total_missing_hours); ?>

                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </td>
            <td>
              <?php if($t->termTotals != null): ?>
                <?php $__currentLoopData = $t->termTotals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <?php if($tt->term_id == $term_id): ?>
                    <?php echo e($tt->total_substitute_hours); ?>

                  <?php endif; ?>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
              <?php endif; ?>
            </td>

            <td>
                <a href="<?php echo e(route('teachers.show',array($t->id,'term_id'=>$term_id))); ?>" class="btn btn-info">查看详情</a>
                <?php if($t->status == true): ?>
                <a href="<?php echo e(route('teachers.edit',array($t->id,'term_id'=>$term_id))); ?>" class="btn btn-primary">关联课程</a>
                <form action="<?php echo e(route('teachers.remove',$t->id)); ?>" method="POST" style="display: inline-block;">
                  <?php echo e(method_field('PATCH')); ?>

                  <?php echo e(csrf_field()); ?>

                  <button type="submit" class="btn btn-warning" type="button" onclick="delcfm();">老师离职</button>
                </form>
                <?php else: ?>
                <button type="" class="btn btn-primary" type="button" disabled="">关联课程</button>
                <button type="" class="btn btn-danger" type="button" disabled="">已离职</button>
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php else: ?>
</table>
<?php echo $__env->make('shared._nothing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php if(count($teachers)>config('page.PAGE_SIZE')): ?>
<?php echo $__env->make('shared._pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<?php endif; ?>
<script>

  function delcfm() {
      if (!confirm("确认操作？")) {
          window.event.returnValue = false;
      }
  };

  $(function(){
      $('.chosen-select').chosen({no_results_text: "Oops, nothing found!"});
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/teachers/index.blade.php ENDPATH**/ ?>