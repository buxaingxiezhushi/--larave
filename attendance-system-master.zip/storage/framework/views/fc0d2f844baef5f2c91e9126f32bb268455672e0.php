<?php $__env->startSection('title','离职员工信息'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form class="form-inline definewidth m20" action="<?php echo e(route('leave_staffs.index')); ?>" method="get">
    员工姓名：
    <input type="text" name="staffname" id="staffname"class="abc input-default" placeholder="" value="">&nbsp;&nbsp;
    <button type="submit" class="btn btn-primary">查询</button>
    &nbsp;&nbsp;
    <a href="<?php echo e(route('staffs.index')); ?>" class="btn btn-info">查看在职员工</a>
</form>

<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>员工编号</th>
        <th>员工姓名</th>
        <th>英文名</th>
        <th>所属部门</th>
        <th>当前职位</th>
        <th>入职日期</th>
        <th>离职日期</th>
        <th>参加工作年数</th>
        <th>年假小时数</th>
        <th>剩余小时</th>
        <th>调休小时数</th>
        <th>剩余小时</th>
        <th>状态</th>
        <th>操作</th>
    </tr>
    </thead>
    <tbody id="pageInfo">
    <?php $__currentLoopData = $leave_staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $leave_staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
            <td><?php echo e($leave_staff->id); ?></td>
            <td><?php echo e($leave_staff->staffname); ?></td>
            <td><?php echo e($leave_staff->englishname); ?></td>
            <td><?php echo e($leave_staff->department_name); ?></td>
            <td><?php echo e($leave_staff->position_name); ?></td>
            <td><?php echo e($leave_staff->join_company); ?></td>
            <td><?php echo e($leave_staff->leave_company); ?></td>
            <td><?php echo e($leave_staff->work_year); ?></td>
            <td><?php echo e($leave_staff->annual_holiday); ?></td>
            <td><?php echo e($leave_staff->remaining_annual_holiday); ?></td>
            <?php if($leave_staff->lieu != null): ?>
              <td><?php echo e($leave_staff->lieu->total_time); ?></td>
              <td><?php echo e($leave_staff->lieu->remaining_time); ?></td>
            <?php else: ?>
              <td></td>
              <td></td>
            <?php endif; ?>
            <td><button class="btn btn-danger disabled" type="button">已离职</button></td>
            <td>
                <a href="<?php echo e(route('leave_staffs.show',$leave_staff->id)); ?>" class="btn btn-info">详情</a>
            </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php if(count($leave_staffs)>config('page.PAGE_SIZE')): ?>
<?php echo $__env->make('shared._pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<script>

  function delcfm() {
      if (!confirm("确认操作？")) {
          window.event.returnValue = false;
      }
  }

</script>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/leave_staffs/index.blade.php ENDPATH**/ ?>