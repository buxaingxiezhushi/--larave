<?php $__env->startSection('title','上课考勤信息'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('shared._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container" style="margin: 5% auto;">

<br><br><br><br><br>
<table class="table table-bordered table-hover m10" style="width: 500px; margin:0 auto;">
    <thead>
    <tr>
        <th style="text-align: center;" colspan="2">查询上课考勤记录</th>
    </tr>
    </thead>

    <form class="form-inline definewidth m20" action="<?php echo e(route('lesson_attendances.teacher_results')); ?>" method="GET">
      <tr>
        <td style="text-align: center;" colspan="2">
          选择学期：
          <select name="term_id" id="term_id">
            <?php $__currentLoopData = $terms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $term): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <option value="<?php echo e($term->id); ?>"
            <?php if($term_id == $term->id): ?>
            selected
            <?php endif; ?>
            ><?php echo e($term->term_name); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
          </select>
        </td>
      </tr>
      <tr>
        <td style="text-align: center;">
        开始月份：
          <select name="start_month" id="start_month">
            <option value="">请选择...</option>
            <?php for($i=1; $i<=12; $i++): ?>
              <option value="<?php echo e($i); ?>" <?php if(date('m')-1 == $i): ?> selected <?php endif; ?>><?php echo e($i); ?>月</option>
            <?php endfor; ?>
          </select>
        </td>

        <td style="text-align: center;">
        结束月份：
          <select name="end_month" id="end_month">
            <option value="">请选择...</option>
            <?php for($i=1; $i<=12; $i++): ?>
              <option value="<?php echo e($i); ?>"><?php echo e($i); ?>月</option>
            <?php endfor; ?>
          </select>
        </td>
      </tr>
      <tr>
          <td style="text-align: center;" colspan="2">
            <button type="submit" class="btn btn-primary">查询</button>
          </td>
      </tr>
    </form>
</table>
</div>

<script>

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/lesson_attendances/index.blade.php ENDPATH**/ ?>