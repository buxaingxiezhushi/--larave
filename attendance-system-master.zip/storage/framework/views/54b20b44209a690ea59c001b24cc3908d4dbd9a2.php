<!DOCTYPE html>
<html>
<head>
    <title><?php echo $__env->yieldContent('title', '考勤管理系统'); ?> - 刘少华的教培机构</title>
    <meta charset="UTF-8">
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/bootstrap-responsive.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/style.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/chosen.css')); ?>" />
    <link rel="stylesheet" type="text/css" href="<?php echo e(asset('css/paginate.css')); ?>" />
    <script type="text/javascript" src="<?php echo e(asset('js/jquery.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/jquery-1.8.1.min.js')); ?>"></script>
<!--     <script type="text/javascript" src="../Js/jquery.sorted.js"></script> -->
    <script type="text/javascript" src="<?php echo e(asset('js/bootstrap.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/ckform.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/common.js')); ?>"></script>
    <script type="text/javascript" src="<?php echo e(asset('js/chosen.jquery.js')); ?>"></script>



    <style type="text/css">
        body {
            padding-bottom: 40px;
        }
        .sidebar-nav {
            padding: 9px 0;
        }

        @media (max-width: 980px) {
            /* Enable use of floated navbar text */
            .navbar-text.pull-right {
                float: none;
                padding-left: 5px;
                padding-right: 5px;
            }
        }

        .black_overlay{
            display: none;
            position: absolute;
            top: 0%;
            left: 0%;
            width: 100%;
            height: 100%;
            background-color: black;
            z-index:1001;
            -moz-opacity: 0.8;
            opacity:.30;
            filter: alpha(opacity=88);
        }
        .white_content {
            display: none;
            position: absolute;
            top: 25%;
            left: 35%;
            width: 25%;
            height: 25%;
            padding: 10px;
            /*border: 10px solid orange;*/
            background-color: white;
            z-index:1002;
            overflow: auto;
        }

    </style>
</head>
<body>
<?php echo $__env->yieldContent('content'); ?>
</body>
</html>
<?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/layouts/default.blade.php ENDPATH**/ ?>