<?php $__env->startSection('title','编辑员工'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<div class="container">
<?php echo $__env->make('shared._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('staffs.update', $staff->id)); ?>" method="post" class="definewidth m20">
  <?php echo e(method_field('PATCH')); ?>

  <?php echo e(csrf_field()); ?>

  <table class="table table-bordered table-hover definewidth m10">
      <tr>
          <td width="10%" class="tableleft">员工姓名</td>
          <td><input type="text" name="staffname" value="<?php echo e($staff->staffname); ?>" disabled/></td>
      </tr>
      <tr>
          <td class="tableleft">英文名</td>
          <td><input type="text" name="englishname" value="<?php echo e($staff->englishname); ?>" disabled/></td>
      </tr>
      <tr>
          <td class="tableleft">员工编号*</td>
          <td><input type="text" name="id" value="<?php echo e($staff->id); ?>" disabled/></td>
      </tr>
      <tr>
          <td class="tableleft">所属部门</td>
           <td>
            <select name="departments">
              <option value="">----请选择----</option>
              <?php $__currentLoopData = $departments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $d): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(($staff->department_name)===$d->department_name): ?>
                <option value="<?php echo e($d->id); ?>" selected="selected"><?php echo e($d->department_name); ?></option>
                <?php else: ?>
                <option value="<?php echo e($d->id); ?>"><?php echo e($d->department_name); ?></option>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </td>
      </tr>
      <tr>
          <td class="tableleft">当前职位*</td>
           <td>
            <select name="positions">
              <option value="">----请选择----</option>
              <?php $__currentLoopData = $positions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $p): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <?php if(($staff->position_name)===$p->position_name): ?>
                <option value="<?php echo e($p->id); ?>" selected="selected"> <?php echo e($p->position_name); ?></option>
                <?php else: ?>
                <option value="<?php echo e($p->id); ?>"><?php echo e($p->position_name); ?></option>
                <?php endif; ?>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
          </td>
      </tr>
      <tr>
          <td class="tableleft" >入职日期</td>
          <td>
            <input type="date" name="join_company" value="<?php echo e($staff->join_company); ?>" min="" max="<?php echo e(date('Y-m-d')); ?>" disabled />
          </td>
      </tr>
      <tr>
          <td class="tableleft">年假小时数</td>
          <td><input type="text" name="annual_holiday" placeholder="" value="<?php echo e($staff->annual_holiday); ?>" /></td>
      </tr>
      <tr>
          <td class="tableleft">剩余小时数</td>
          <td><input type="text" name="remaining_annual_holiday" placeholder="" value="<?php echo e($staff->remaining_annual_holiday); ?>" /></td>
      </tr>

      <tr>
          <td class="tableleft">调休小时数</td>
          <?php if($staff->lieu != null): ?>
          <td><input type="text" name="lieu_total_time" placeholder="" value="<?php echo e($staff->lieu->total_time); ?>" /></td>
          <?php else: ?>
          <td><input type="text" name="lieu_total_time" placeholder="" value="0.00" /></td>
          <?php endif; ?>
      </tr>
      <tr>
          <td class="tableleft">剩余小时数</td>
          <?php if($staff->lieu != null): ?>
          <td><input type="text" name="lieu_remaining_time" placeholder="" value="<?php echo e($staff->lieu->remaining_time); ?>" /></td>
          <?php else: ?>
          <td><input type="text" name="lieu_remaining_time" placeholder="" value="0.00" /></td>
          <?php endif; ?>
      </tr>

      <tr>
          <td class="tableleft">工作经历</td>
          <td>
            <?php for($i=0;$i<=9;$i++): ?>
              <?php if($i<$count): ?>
              <input type="date" name="work_experiences[<?php echo e($i); ?>]" value="<?php echo e($work_historys[$i]->work_experience); ?>"/> &nbsp;至&nbsp; <input type="date" name="leave_experiences[<?php echo e($i); ?>]" value="<?php echo e($work_historys[$i]->leave_experience); ?>"/> <br>
              <?php else: ?>
              <input type="date" name="work_experiences[<?php echo e($i); ?>]"/> &nbsp;至&nbsp; <input type="date" name="leave_experiences[<?php echo e($i); ?>]"/> <br>
              <?php endif; ?>
            <?php endfor; ?>
            *修改工作经历会自动更新年假
          </td>
      </tr>

      <tr>
        <td class="tableleft">工资卡</td>
        <?php if($staff->card != null): ?>
        <td><input id="card" type="text" name="card_number" value="<?php echo e($staff->card->card_number); ?>" maxlength="23"></td>
        <?php else: ?>
        <td><input id="card" type="text" name="card_number" value="<?php echo e(old('card_number')); ?>" maxlength="23"></td>
        <?php endif; ?>
      </tr>

      <tr>
        <td class="tableleft">开户行</td>
        <?php if($staff->card != null): ?>
        <td><input type="text" name="bank" value="<?php echo e($staff->card->bank); ?>"></td>
        <?php else: ?>
        <td><input type="text" name="bank" value="<?php echo e(old('bank')); ?>"></td>
        <?php endif; ?>
      </tr>

      <tr>
          <td class="tableleft"></td>
          <td>
              <button type="submit" class="btn btn-primary" type="button">提交</button> &nbsp;&nbsp;<a class="btn btn-success" href="<?php echo e(route('staffs.index')); ?>" role="button">返回列表</a>
          </td>
      </tr>
  </table>
</form>

</div>



<script>
  var defaultDate = document.querySelectorAll('#date-picker');
  for (var i = 0; i<defaultDate.length; i++) {
    defaultDate[i].valueAsDate = new Date();
  }

  window.onload=function()
  {
    var oT=document.getElementById('card');
    oT.onkeydown=function(ev)
    {
      var oW=oT.value;
      var oEvent=ev||event;
      if(oEvent.keyCode==8)
      {
        if(oW)
        {
          for(var i=0;i<oW.length;i++)
          {
            var newStr=oW.replace(/\s$/g,'');
          }
          oT.value=newStr
        }
      }else{
        for(var i=0;i<oW.length;i++)
        {
          var arr=oW.split('');

          if((i+1)%5==0)
          {
            arr.splice(i,0,' ');
          }
        }
        oT.value=arr.join('');
      }
    }
  }
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/staffs/edit.blade.php ENDPATH**/ ?>