<?php $__env->startSection('title','员工信息'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form class="form-inline definewidth m20" action="<?php echo e(route('staffs.index')); ?>" method="get">
    员工英文名
    <input type="text" name="englishname" id="englishname"class="abc input-default" placeholder="" value="<?php echo e(old('englishname')); ?>">&nbsp;&nbsp;
    <button type="submit" class="btn btn-primary">查询</button>
    &nbsp;&nbsp;
  <div class="btn-group">
    <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown">
    新增员工 <span class="caret"></span></button>
    <ul class="dropdown-menu" role="menu">
    <a class="btn btn-link" href="<?php echo e(route('staffs.create')); ?>" role="button">正式员工</a>
    &nbsp;&nbsp;
    <a class="btn btn-link" href="<?php echo e(route('staffs.create_part_time')); ?>" role="button">兼职员工</a>
    </ul>
  </div>
  &nbsp;&nbsp;

  <div class="btn-group">
    <button type="button" class="btn btn-info dropdown-toggle" data-toggle="dropdown">
    查看员工 <span class="caret"></span></button>
    <ul class="dropdown-menu" role="menu">
    <a class="btn btn-link" href="<?php echo e(route('staffs.part_time_index')); ?>">兼职员工</a>
    &nbsp;&nbsp;
    <a href="<?php echo e(route('leave_staffs.index')); ?>" class="btn btn-link">离职员工</a>
    </ul>
  </div>



</form>

<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>员工编号</th>
        <th>员工姓名</th>
        <th>英文名</th>
        <th>所属部门</th>
        <th>当前职位</th>
        <th>入职日期</th>
        <th>参加工作年数</th>
        <th>年假小时数</th>
        <th>剩余小时</th>
        <th>调休小时数</th>
        <th>剩余小时</th>
        <th>操作</th>
    </tr>
    </thead>
    <tbody id="pageInfo">
    <?php $__currentLoopData = $staffs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $staff): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
            <td><?php echo e($staff->id); ?></td>
            <td><?php echo e($staff->staffname); ?></td>
            <td><?php echo e($staff->englishname); ?></td>
            <td><?php echo e($staff->department_name); ?></td>
            <td><?php echo e($staff->position_name); ?></td>
            <td><?php echo e($staff->join_company); ?></td>
            <td><?php echo e($staff->work_year); ?></td>
            <td><?php echo e(round($staff->annual_holiday,1)); ?></td>
            <td><?php echo e(round($staff->remaining_annual_holiday,1)); ?></td>
            <?php if($staff->lieu != null): ?>
              <td><?php echo e(round($staff->lieu->total_time,1)); ?></td>
              <td><?php echo e(round($staff->lieu->remaining_time,1)); ?></td>
            <?php else: ?>
              <td></td>
              <td></td>
            <?php endif; ?>
            <td>
              <a href="<?php echo e(route('staffs.show',$staff->id)); ?>" class="btn btn-info">详情</a>
              <a href="<?php echo e(route('staffs.edit',$staff->id)); ?>" class="btn btn-primary">编辑信息</a>
              <a href="<?php echo e(route('staffs.edit_work_time',$staff->id)); ?>" class="btn btn-primary">修改排班</a>
              <?php if($staff->lieu == null && count($staff->extraWorks)==0 && count($staff->absences)==0 && count($staff->totalAttendances)==0 && $staff->teacher_id == null): ?>
              <div class="btn-group">
                <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown">
                操作 <span class="caret"></span></button>
                <ul class="dropdown-menu" role="menu">
                  <form action="<?php echo e(route('staffs.leave', $staff->id)); ?>" method="POST">
                    <?php echo e(method_field('PATCH')); ?>

                    <?php echo e(csrf_field()); ?>

                    <button type="submit" class="btn btn-link" type="button" onclick="delcfm();">员工离职</button>
                  </form>
                  <form action="<?php echo e(route('staffs.destroy', $staff->id)); ?>" method="POST">
                    <?php echo e(method_field('DELETE')); ?>

                    <?php echo e(csrf_field()); ?>

                    <button type="submit" class="btn btn-link" type="button" onclick="delcfm();">删除</button>
                  </form>
                </ul>
              </div>
              <?php else: ?>
              <form action="<?php echo e(route('staffs.leave', $staff->id)); ?>" method="POST" style="display: inline-block;">
                <?php echo e(method_field('PATCH')); ?>

                <?php echo e(csrf_field()); ?>

                <button type="submit" class="btn btn-warning" type="button" onclick="delcfm();">员工离职</button>
              </form>
              <?php endif; ?>
            </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php if(count($staffs)>config('page.PAGE_SIZE')): ?>
<?php echo $__env->make('shared._pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<script>

  function delcfm() {
      if (!confirm("确认操作？")) {
          window.event.returnValue = false;
      }
  }

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/staffs/index.blade.php ENDPATH**/ ?>