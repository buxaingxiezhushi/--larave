  <?php if(session()->has("danger")): ?>
      <p style="color: red;">
        <?php echo e(session()->get("danger")); ?>

      </p>
  <?php elseif(session()->has('success')): ?>
      <p style="color: green;">
        <?php echo e(session()->get("success")); ?>

      </p>
  <?php endif; ?>
<?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/shared/_warnings.blade.php ENDPATH**/ ?>