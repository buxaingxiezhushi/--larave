<?php $__env->startSection('title','一键换课'); ?>
<?php $__env->startSection('content'); ?>
<div class="container">
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('shared._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<form action="<?php echo e(route('alters.store_all',array('current_term_id'=>$current_term_id))); ?>" method="POST" class="definewidth m20">
<table class="table table-bordered table-hover definewidth m10">
  <?php echo e(csrf_field()); ?>

    <tr>
      <td class="tableleft">当前学期</td>
      <td>
        <input type="text" name="term_name" value="<?php echo e($term->term_name); ?>" disabled="">
      </td>
    </tr>

    <tr>
        <td width="10%" class="tableleft">上课日期*</td>
        <td>
          <input type="date" name="lesson_date" value="<?php echo e(old('lesson_date')); ?>">
        </td>
    </tr>
    <tr>
      <td width="10%" class="tableleft">调整日期*</td>
      <td>
        <input type="date" name="alter_date" value="<?php echo e(old('alter_date')); ?>">
      </td>
    </tr>
    <tr>
        <td class="tableleft"></td>
        <td>
            <button type="submit" class="btn btn-primary" type="button">提交</button> &nbsp;&nbsp;<a class="btn btn-success" href="<?php echo e(route('alters.index', array('term_id'=>$current_term_id))); ?>" role="button">返回代课管理</a>
        </td>
    </tr>
</table>
</form>
</div>

<script>
  $(function(){
    $('#lesson_select').chosen();
  });
</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/alters/one_time.blade.php ENDPATH**/ ?>