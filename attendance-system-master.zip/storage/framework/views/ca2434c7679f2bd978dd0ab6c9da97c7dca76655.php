<?php $__env->startSection('title','老师信息'); ?>
<?php $__env->startSection('content'); ?>
<h4 style="margin: 20px;"><?php echo e($teacher->staff->englishname); ?></h4>

<h5 style="margin: 20px;">上课安排 - <?php echo e($term->term_name); ?></h5>
<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>课程名称</th>
        <th>上课时间</th>
        <th>教室</th>
        <th>时长</th>
    </tr>
    </thead>

    <?php if(count($lessons) != 0): ?>
    <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $l): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
        <?php if($flag): ?>
          <?php if($l->day == 'Mon'): ?>
          <td><?php echo e($l->lesson_name); ?></td>
          <td><?php echo e(date('H:i',strtotime($l->start_time))); ?>-<?php echo e(date('H:i',strtotime($l->end_time))); ?></td>
          <td><?php echo e($l->classroom); ?></td>
          <td><?php echo e($l->duration); ?></td>
          <?php endif; ?>
        <?php else: ?>
          <td><?php echo e($l->lesson_name); ?></td>
          <td><?php echo e($l->day); ?>-<?php echo e(date('H:i',strtotime($l->start_time))); ?>-<?php echo e(date('H:i',strtotime($l->end_time))); ?></td>
          <td><?php echo e($l->classroom); ?></td>
          <td><?php echo e($l->duration); ?></td>
        <?php endif; ?>
      </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php else: ?>
</table>
<?php echo $__env->make('shared._nothing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<h5 style="margin: 20px;">每月时长</h5>
<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>月份</th>
        <?php if(stristr($term->term_name,'Summer')): ?>
        <th>周一</th>
        <th>周三</th>
        <th>周五</th>
        <th>其他</th>
        <?php else: ?>
        <th>周五</th>
        <th>周六</th>
        <th>周日</th>
        <th>其他</th>
        <?php endif; ?>
        <th>实际排课</th>
        <th>应排课</th>
    </tr>
    </thead>
    <?php if(count($month_durations) != 0): ?>
    <?php if(stristr($term->term_name,'Summer')): ?>
    <?php $__currentLoopData = $month_durations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(array_key_exists($md->month,$month_should_durations)): ?>
      <tr>
        <td><?php echo e($md->month); ?></td>
        <td><?php echo e($md->mon_duration); ?></td>
        <td><?php echo e($md->wed_duration); ?></td>
        <td><?php echo e($md->fri_duration); ?></td>
        <td><?php echo e($md->other_duration); ?></td>
        <td><?php echo e($md->actual_duration); ?></td>
        <td><?php echo e($month_should_durations[$md->month]); ?></td>
      </tr>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php else: ?>
    <?php $__currentLoopData = $month_durations; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $md): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if(array_key_exists($md->month,$month_should_durations)): ?>
      <tr>
        <td><?php echo e($md->month); ?></td>
        <td><?php echo e($md->fri_duration); ?></td>
        <td><?php echo e($md->sat_duration); ?></td>
        <td><?php echo e($md->sun_duration); ?></td>
        <td><?php echo e($md->other_duration); ?></td>
        <td><?php echo e($md->actual_duration); ?></td>
        <td><?php echo e($month_should_durations[$md->month]); ?></td>
      </tr>
      <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php endif; ?>
</table>
<?php else: ?>
</table>
<?php echo $__env->make('shared._nothing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<br>
<br>
<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>缺课课时(学期累计)</th>
        <th>代课课时(学期累计)</th>
    </tr>
    </thead>
    <?php if(count($term_totals) != 0): ?>
    <tr>
      <?php $__currentLoopData = $term_totals; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php if($tt->total_missing_hours != null): ?>
      <td><?php echo e($tt->total_missing_hours); ?>小时</td>
      <?php else: ?>
      <td>0小时</td>
      <?php endif; ?>
      <?php if($tt->total_substitute_hours != null): ?>
      <td><?php echo e($tt->total_substitute_hours); ?>小时</td>
      <?php else: ?>
      <td>0小时</td>
      <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tr>
</table>
<?php else: ?>
</table>
<?php echo $__env->make('shared._nothing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<h5 style="margin: 20px;">课程时间变更信息</h5>
<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>课程名称</th>
        <th>星期</th>
        <th>时长</th>
        <th>有效日期</th>
    </tr>
    </thead>
    <?php if(count($lessons) != 0): ?>
      <?php $__currentLoopData = $lessons; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lesson): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <?php $__currentLoopData = $lesson->lessonUpdates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$lu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($key < count($lesson->lessonUpdates)-1): ?>
        <tr>
          <td>
            <?php echo e($lesson->lesson_name); ?>

          </td>
          <td>
            <?php echo e($lu->day); ?>

          </td>
          <td>
            <?php echo e($lu->duration); ?>

          </td>
          <td>
            <?php echo e($lu->start_date); ?> ~ <?php echo e($lu->end_date); ?>

          </td>
        </tr>
        <?php endif; ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php else: ?>
</table>
<?php echo $__env->make('shared._nothing', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>

<div style="margin: 20px">
  <?php if($teacher->status == true): ?>
  <a class="btn btn-primary"  href="<?php echo e(route('teachers.edit',array($teacher->id,'term_id'=>$current_term_id))); ?>" role="button">关联课程</a>&nbsp;&nbsp;
  <?php endif; ?>
  <a class="btn btn-success" href="<?php echo e(route('teachers.index',array('term_id'=>$current_term_id))); ?>" role="button">返回列表</a>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/teachers/show.blade.php ENDPATH**/ ?>