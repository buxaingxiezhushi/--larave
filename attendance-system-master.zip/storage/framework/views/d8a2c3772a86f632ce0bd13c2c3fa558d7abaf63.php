<?php $__env->startSection('title','员工个人信息'); ?>
<?php $__env->startSection('content'); ?>
<h4 style="margin: 20px;">员工个人信息 - <?php echo e($staff->staffname); ?></h4>
<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>员工编号</th>
        <th>员工姓名</th>
        <th>英文名</th>
        <th>所属部门</th>
        <th>职位</th>
        <th>入职日期</th>
        <th>参加工作年数</th>
    </tr>
    </thead>
       <tr>
            <td><?php echo e($staff->id); ?></td>
            <td><?php echo e($staff->staffname); ?></td>
            <td><?php echo e($staff->englishname); ?></td>
            <td><?php echo e($staff->department_name); ?></td>
            <td><?php echo e($staff->position_name); ?></td>
            <td><?php echo e($staff->join_company); ?></td>
            <td><?php echo e($staff->work_year); ?></td>
</table>


<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>总年假(小时)</th>
        <th>剩余小时</th>
        <th>总调休(小时)</th>
        <th>剩余小时</th>
    </tr>
    </thead>
    <tr>
        <td><?php echo e($staff->annual_holiday); ?></td>
        <td><?php echo e($staff->remaining_annual_holiday); ?></td>
        <?php if($staff->lieu != null): ?>
          <td><?php echo e($staff->lieu->total_time); ?></td>
          <td><?php echo e($staff->lieu->remaining_time); ?></td>
        <?php else: ?>
          <td>0.00</td>
          <td>0.00</td>
        <?php endif; ?>
    </tr>
</table>

<table class="table table-bordered table-hover definewidth m10">
  <h4 style="margin-left: 20px; margin-right: 20px; margin-top: 20px; margin-bottom: 0px;">一周排班</h4>
    <thead>
    <tr>
        <th>星期</th>
        <th>应上班时间</th>
        <th>应下班时间</th>
    </tr>
    </thead>
    <?php $__currentLoopData = $staffworkdays; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $workday): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($workday->workday_name); ?></td>
        <?php if($workday->work_time != null): ?>
        <td><?php echo e(date("H:i",strtotime($workday->work_time))); ?></td>
        <?php else: ?>
        <td>休息</td>
        <?php endif; ?>

        <?php if($workday->home_time != null): ?>
        <td><?php echo e(date("H:i",strtotime($workday->home_time))); ?></td>
        <?php else: ?>
        <td>休息</td>
        <?php endif; ?>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<br>
<?php if(count($work_historys) != 0): ?>
<table class="table table-bordered table-hover definewidth m10">
  <h4 style="margin: 0px 20px;">工作经历</h4>
    <thead>
    <tr>
        <th>入职日期</th>
        <th>离职日期</th>
    </tr>
    </thead>
    <?php $__currentLoopData = $work_historys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $wh): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <tr>
        <td><?php echo e($wh->work_experience); ?></td>
        <td><?php echo e($wh->leave_experience); ?></td>
    </tr>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>
<?php endif; ?>

<div style="margin: 20px">
  <a class="btn btn-success" href="<?php echo e(route('leave_staffs.index')); ?>" role="button">返回列表</a>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/leave_staffs/show.blade.php ENDPATH**/ ?>