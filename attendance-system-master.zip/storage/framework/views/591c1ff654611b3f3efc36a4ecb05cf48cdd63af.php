<?php $__env->startSection('title','请假信息'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<form class="form-inline definewidth m20" action="<?php echo e(route('absences.index')); ?>" method="get">
    员工英文名
    <input type="text" name="englishname" id="englishname"class="abc input-default" placeholder="" value="<?php echo e(old('englishname')); ?>">&nbsp;&nbsp;
    <button type="submit" class="btn btn-primary">查询</button>&nbsp;&nbsp;
    <a class="btn btn-success" href="<?php echo e(route('absences.create')); ?>" role="button">新增请假</a>
</form>

<form action="<?php echo e(route('absences.export_absence')); ?>" method="POST" style="margin-top: 10px; margin-left: 25px;">
  <?php echo e(csrf_field()); ?>

  开始日期&nbsp;&nbsp;<input type="date" name="start_date" value="old('start_date')">
  &nbsp;&nbsp;
  结束日期&nbsp;<input type="date" name="end_date" value="old('end_date')">
  &nbsp;&nbsp;
  <button type="submit" class="btn btn-success" type="button">导出请假记录</button>
</form>
<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>员工编号</th>
        <th>员工姓名</th>
        <th>英文名</th>
        <th>所属部门</th>
        <th>请假类型</th>
        <th>请假时间</th>
        <th>时长</th>
        <th>是否批准</th>
        <th>备注</th>
        <th>创建日期</th>
        <th>上次修改</th>
        <th>操作</th>
    </tr>
    </thead>
    <tbody id="pageInfo">
    <?php $__currentLoopData = $absences; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $absence): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
            <td><?php echo e($absence->staff->id); ?></td>
            <td><?php echo e($absence->staff->staffname); ?></td>
            <td><?php echo e($absence->staff->englishname); ?></td>
            <td><?php echo e($absence->staff->department_name); ?></td>
            <td><?php echo e($absence->absence_type); ?></td>
            <td><?php echo e(date("Y-m-d H:i", strtotime($absence->absence_start_time))); ?> 至 <?php echo e(date("Y-m-d H:i", strtotime($absence->absence_end_time))); ?></td>
            <td><?php echo e($absence->duration); ?></td>
            <td>
              <?php if($absence->approve == true): ?> 是
              <?php else: ?> 否
              <?php endif; ?>
            </td>
            <td><?php echo e($absence->note); ?></td>
            <td><?php echo e($absence->created_at); ?></td>
            <td><?php echo e($absence->updated_at); ?></td>
            <td>
                <a href="<?php echo e(route('absences.edit',$absence->id)); ?>" class="btn btn-primary">编辑</a> <!-- route('staffs.edit', $staff->id) -->

                <form action="<?php echo e(route('absences.destroy', $absence->id)); ?>" method="POST" style="display: inline-block;">
                  <?php echo e(method_field('DELETE')); ?>

                  <?php echo e(csrf_field()); ?>

                  <button type="submit" class="btn btn-danger" type="button" onclick="delcfm();">删除</button>
                </form>
            </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>

<?php if(count($absences)>config('page.PAGE_SIZE')): ?>
<?php echo $__env->make('shared._pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<script>

  function delcfm() {
      if (!confirm("删除记录可能影响考勤结果，确认要删除？")) {
          window.event.returnValue = false;//这句话关键，没有的话，还是会执行下一步的
      }
  }

</script>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/absences/index.blade.php ENDPATH**/ ?>