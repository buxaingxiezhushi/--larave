<?php $__env->startSection('title','考勤汇总信息'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('shared._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h4 style="text-align: center"><?php echo e($term->term_name); ?> 老师上课考勤汇总</h4>
<hr>
<?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$t): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<h5 style="text-align: center"><?php echo e($t->staff->englishname); ?>-<?php echo e($t->staff->position_name); ?></h5>
<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>月份</th>
        <th>应排课</th>
        <th>实际排课</th>
        <th>实际上课</th>
        <th>缺少课时</th>
    </tr>
    </thead>
    <tbody id="pageInfo">
      <?php $__currentLoopData = $all_teacher_durations[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $m=>$td): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> <!-- $td是这个老师每一个月的duration -->
      <tr>
        <?php if($td != null): ?>
          <td><?php echo e($m); ?></td>
          <td><?php echo e($td[0]); ?></td>
          <td><?php echo e($td[1]); ?></td>
          <td><?php echo e($td[2]); ?></td>
          <?php if($td[3]>0): ?>
          <td><?php echo e($td[3]); ?></td>
          <?php else: ?>
          <td>0</td>
          <?php endif; ?>
        <?php endif; ?>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <tr>
          <td>合计</td>
          <td><?php echo e($all_teacher_total_durations[$key][0]); ?></td>
          <td><?php echo e($all_teacher_total_durations[$key][1]); ?></td>
          <td><?php echo e($all_teacher_total_durations[$key][2]); ?></td>
          <?php if($all_teacher_total_durations[$key][3]>0): ?>
          <td><?php echo e($all_teacher_total_durations[$key][3]); ?></td>
          <?php else: ?>
          <td>0</td>
          <?php endif; ?>
      </tr>
    </tbody>
</table>

<?php if(count($all_teacher_extra_works[$key]) != 0): ?>
<div style="text-align: center; margin-top: 5px;">加班记录</div>
<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>日期</th>
        <th>实际时长</th>
        <th>转换时长</th>
        <th>备注</th>
    </tr>
    </thead>
    <tbody id="pageInfo">
      <?php $__currentLoopData = $all_teacher_extra_works[$key]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $atew): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <tr>
          <td><?php echo e(date('Y-m-d', strtotime($atew->extra_work_start_time))); ?></td>
          <td><?php echo e(($atew->duration)*1.0); ?></td>
          <?php if($atew->extra_work_type == '带薪 1:1.2'): ?>
          <td><?php echo e(($atew->duration)*1.2); ?></td>
          <td><?php echo e($atew->extra_work_type); ?>抵课时</td>
          <?php else: ?>
          <td><?php echo e(($atew->duration)*1.0); ?></td>
          <td><?php echo e($atew->extra_work_type); ?>抵课时</td>
          <?php endif; ?>
      </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <tr>
          <td style="font-weight: bold;">总计</td>
          <td></td>
          <td><?php echo e($all_teacher_extra_work_durations[$key]); ?></td>
          <td></td>
      </tr>
      <tr>
          <td style="font-weight: bold;">缺少课时</td>
          <td></td>
          <?php if(($all_teacher_total_durations[$key][3] - $all_teacher_extra_work_durations[$key])>0): ?>
          <td style="color: red;"><?php echo e($all_teacher_total_durations[$key][3] - $all_teacher_extra_work_durations[$key]); ?></td>
          <?php else: ?>
          <td style="color: red;">0</td>
          <?php endif; ?>
          <td></td>
      </tr>
    </tbody>
</table>
<?php endif; ?>
<hr>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

<?php if(count($teachers)>config('page.PAGE_SIZE')): ?>
<?php echo $__env->make('shared._pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<div style="margin: 20px">
  <a class="btn btn-success" href="<?php echo e(route('lesson_attendances.index',array('term_id'=>$term->term_id))); ?>" role="button">返回</a>
  &nbsp;&nbsp;
  <div class="btn-group">
    <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown">
    导出上课考勤汇总 <span class="caret"></span></button>
    <ul class="dropdown-menu" role="menu">
    <form action="<?php echo e(route('lesson_attendances.export_multiple', array('term_id'=>$term_id,'start_month'=>$search_start_month,'end_month'=>$search_end_month, 'option'=>'全职教师'))); ?>" method="POST">
      <?php echo e(csrf_field()); ?>

      <button type="submit" class="btn btn-link" type="button">全职老师</button>
    </form>

    <form action="<?php echo e(route('lesson_attendances.export_multiple', array('term_id'=>$term_id,'start_month'=>$search_start_month,'end_month'=>$search_end_month, 'option'=>'兼职教师'))); ?>" method="POST">
      <?php echo e(csrf_field()); ?>

      <button type="submit" class="btn btn-link" type="button">兼职老师</button>
    </form>
    </ul>
  </div>
</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/lesson_attendances/teacher_multiple_results.blade.php ENDPATH**/ ?>