<?php $__env->startSection('title','考勤信息'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->make('shared._errors', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h4 style="text-align: center"><?php echo e($year); ?>年<?php echo e($month); ?>月 考勤汇总</h4>

<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>员工编号</th>
        <th>员工姓名</th>
        <th>英文名</th>
        <th>所属部门</th>
        <th>职位</th>
        <th>总应</th>
        <th>总实</th>
        <th>总基本</th>
        <th>总额外</th>
        <th>总加班</th>
        <th>总请假</th>
        <th>总迟到</th>
        <th>总早退</th>
        <th>出勤天数</th>
        <th>工时差值</th>
        <th>总增补</th>
        <th>是否异常</th>
        <th>操作</th>
    </tr>
    </thead>
    <tbody id="pageInfo">
      <?php $__currentLoopData = $total_attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $ta): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
            <td><?php echo e($ta->staff->id); ?></td>
            <td><?php echo e($ta->staff->staffname); ?></td>
            <td><?php echo e($ta->staff->englishname); ?></td>
            <td><?php echo e($ta->staff->department_name); ?></td>
            <td><?php echo e($ta->staff->position_name); ?></td>
            <td><?php echo e($ta->total_should_duration); ?></td>
            <td><?php echo e($ta->total_actual_duration); ?></td>
            <td><?php echo e($ta->total_basic_duration); ?></td>
            <td><?php echo e($ta->total_more_duration); ?></td>
            <td><?php echo e($ta->total_lieu_work_duration); ?> /
              <?php if($ta->total_extra_work_duration == $ta->total_lieu_work_duration): ?>
              0.00
              <?php else: ?>
              <?php echo e($ta->total_salary_work_duration); ?>

              <?php endif; ?>
            </td>
            <td><?php echo e($ta->total_absence_duration); ?></td>
            <td><?php echo e($ta->total_late_work); ?>分,<?php echo e($ta->total_is_late); ?>次</td>
            <td><?php echo e($ta->total_early_home); ?>分,<?php echo e($ta->total_is_early); ?>次</td>
            <td>应:<?php echo e($ta->should_attend); ?>天/实:<?php echo e($ta->actual_attend); ?>天</td>
            <td><?php echo e($ta->difference); ?></td>
            <td><?php echo e($ta->total_add_duration); ?></td>
            <?php if($ta->abnormal == false): ?>
            <td>否</td>
            <?php else: ?>
            <td style="color: red;">是</td>
            <?php endif; ?>
            <td>
                <a style="font-size: 12px;" href="<?php echo e(route('attendances.show',array($ta->id,'year'=>$year,'month'=>$month))); ?>">查看</a>
            </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      <tbody id="pageInfo">
</table>

<?php if(count($total_attendances)>config('page.PAGE_SIZE')): ?>
<?php echo $__env->make('shared._pagination', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php endif; ?>
<div style="margin: 20px">
  <a class="btn btn-success" href="<?php echo e(route('attendances.index')); ?>" role="button">返回考勤管理</a>
  <!-- &nbsp;&nbsp;
  <div class="btn-group">
    <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown">
    导出考勤汇总 <span class="caret"></span></button>
    <ul class="dropdown-menu" role="menu">

    <form action="<?php echo e(route('attendances.export', array('year'=>$year,'month'=>$month,'option'=>'全职员工'))); ?>" method="POST" style="display: inline-block;">
      <?php echo e(csrf_field()); ?>

      <button type="submit" class="btn btn-link" type="button">全职员工</button>
    </form>

    <form action="<?php echo e(route('attendances.export', array('year'=>$year,'month'=>$month,'option'=>'全职教师'))); ?>" method="POST" style="display: inline-block;">
      <?php echo e(csrf_field()); ?>

      <button type="submit" class="btn btn-link" type="button">全职教师</button>
    </form>

    <form action="<?php echo e(route('attendances.export', array('year'=>$year,'month'=>$month,'option'=>'兼职批文'))); ?>" method="POST" style="display: inline-block;">
      <?php echo e(csrf_field()); ?>

      <button type="submit" class="btn btn-link" type="button">兼职批文</button>
    </form>

    <form action="<?php echo e(route('attendances.export', array('year'=>$year,'month'=>$month,'option'=>'兼职助教'))); ?>" method="POST" style="display: inline-block;">
      <?php echo e(csrf_field()); ?>

      <button type="submit" class="btn btn-link" type="button">兼职助教</button>
    </form>
    </ul> -->
  </div>



</div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/attendances/results.blade.php ENDPATH**/ ?>