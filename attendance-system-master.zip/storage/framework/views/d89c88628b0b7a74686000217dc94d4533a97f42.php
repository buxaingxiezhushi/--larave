<?php $__env->startSection('title','员工个人考勤信息'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('shared._messages', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<h4 style="margin: 20px;">员工个人考勤信息</h4>
<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>员工编号</th>
        <th>员工姓名</th>
        <th>英文名</th>
        <th>所属部门</th>
        <th>职位</th>
    </tr>
    </thead>
      <tr>
        <td><?php echo e($staff->id); ?></td>
        <td><b><?php echo e($staff->staffname); ?></b></td>
        <td><b><?php echo e($staff->englishname); ?></b></td>
        <td><?php echo e($staff->department_name); ?></td>
        <td><?php echo e($staff->position_name); ?></td>
      </tr>
</table>


<table class="table table-bordered table-hover definewidth m10">
    <thead>
    <tr>
        <th>类型</th>
        <th>日期</th>
        <th>星期</th>
        <th>应上班</th>
        <th>应下班</th>
        <th>实上班</th>
        <th>实下班</th>
        <th>迟到(分)</th>
        <th>早退(分)</th>
        <th>请假记录</th>
        <th>加班记录</th>
        <th>应工时</th>
        <th>实工时</th>
        <th>基本工时</th>
        <th>是否异常</th>
        <th>增补记录</th>
        <th>异常备注</th>
        <th>操作</th>
    </tr>
    </thead>
      <?php $__currentLoopData = $attendances; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $attendance): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
       <tr>
            <td><?php echo e($attendance->workday_type); ?></td>
            <td><?php echo e($attendance->year); ?>/<?php echo e($attendance->month); ?>/<?php echo e($attendance->date); ?></td>
            <td><?php echo e($attendance->day); ?></td>
            <?php if($attendance->should_work_time != null): ?>
            <td><?php echo e(date("H:i", strtotime($attendance->should_work_time))); ?></td>
            <?php else: ?>
            <td></td>
            <?php endif; ?>
            <?php if($attendance->should_home_time != null): ?>
            <td><?php echo e(date("H:i", strtotime($attendance->should_home_time))); ?></td>
            <?php else: ?>
            <td></td>
            <?php endif; ?>
            <?php if($attendance->actual_work_time != null): ?>
            <td><?php echo e(date("H:i", strtotime($attendance->actual_work_time))); ?></td>
            <?php else: ?>
            <td></td>
            <?php endif; ?>
            <?php if($attendance->actual_home_time != null): ?>
            <td><?php echo e(date("H:i", strtotime($attendance->actual_home_time))); ?></td>
            <?php else: ?>
            <td></td>
            <?php endif; ?>
            <?php if($attendance->late_work>0): ?>
            <td><?php echo e($attendance->late_work); ?></td>
            <?php else: ?>
            <td></td>
            <?php endif; ?>
            <?php if($attendance->early_home>0): ?>
            <td><?php echo e($attendance->early_home); ?></td>
            <?php else: ?>
            <td></td>
            <?php endif; ?>

            <?php if($attendance->absence_id != null): ?>
            <td style="font-size: 12px;">
              <?php echo e($attendance->absence_type); ?>,
              <?php if($attendance->absence->approve): ?>
              批准
              <?php else: ?>
              未批准
              <?php endif; ?>
              <br>
              <?php echo e(date("Y-m-d H:i", strtotime($attendance->absence->absence_start_time))); ?>~<?php echo e(date("Y-m-d H:i", strtotime($attendance->absence->absence_end_time))); ?>

              <br>
              时长:<?php echo e($attendance->absence_duration); ?>

            </td>
            <?php else: ?>
            <td></td>
            <?php endif; ?>

            <?php if($attendance->extraWork != null): ?>
            <td style="font-size: 12px;">
              <?php echo e($attendance->extraWork->extra_work_type); ?>,
              <?php if($attendance->extraWork->approve): ?>
              批准
              <?php else: ?>
              未批准
              <?php endif; ?>
              <br>
              <?php echo e(date("H:i", strtotime($attendance->extraWork->extra_work_start_time))); ?>~<?php echo e(date("H:i", strtotime($attendance->extraWork->extra_work_end_time))); ?>

              <br>
              时长:<?php echo e($attendance->extraWork->duration); ?>

            </td>
            <?php else: ?>
            <td></td>
            <?php endif; ?>

            <td><?php echo e($attendance->should_duration); ?></td>
            <td><?php echo e($attendance->actual_duration); ?></td>
            <td><?php echo e($attendance->basic_duration); ?></td>
            <?php if($attendance->abnormal == false): ?>
            <td>否</td>
            <?php else: ?>
            <td style="color: red;">是</td>
            <?php endif; ?>
            <td style="font-size: 12px;">
              <?php $__currentLoopData = $attendance->addTimes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $at): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              <?php echo e($at->reason); ?>,
              <br>
              <?php echo e(date('H:i', strtotime($at->add_start_time))); ?>~<?php echo e(date('H:i', strtotime($at->add_end_time))); ?>,
              <br>
              时长:<?php echo e($at->duration); ?>.
              <br>
              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </td>
            <?php if($attendance->abnormalNote != null): ?>
            <td><?php echo e($attendance->abnormalNote->note); ?></td>
            <?php else: ?>
            <td></td>
            <?php endif; ?>
            <td>
                <div class="btn-group">
                  <button type="button" class="btn btn-warning dropdown-toggle" data-toggle="dropdown">
                  异常操作 <span class="caret"></span></button>
                  <ul class="dropdown-menu" role="menu">

                    <form action="<?php echo e(route('attendances.addNote', $attendance->id)); ?>" method="GET" style="display: inline-block;">
                      <button type="submit" class="btn btn-link" type="button" <?php if($attendance->abnormalNote != null): ?> disabled <?php endif; ?>>异常备注</button>
                    </form>
                    <form action="<?php echo e(route('attendances.changeAbnormal', $attendance->id)); ?>" method="POST" style="display: inline-block;">
                      <?php echo e(method_field('PATCH')); ?>

                      <?php echo e(csrf_field()); ?>

                      <button type="submit" class="btn btn-link" type="button" onclick="delcfm();" <?php if($attendance->abnormal == false): ?> disabled <?php endif; ?>>更改异常</button>
                    </form>
                    <!-- <li><a href="#">Tablet</a></li> -->
                  </ul>
                </div>


                <div class="btn-group">
                  <button type="button" class="btn btn-success dropdown-toggle" data-toggle="dropdown">
                  增补操作 <span class="caret"></span></button>
                  <ul class="dropdown-menu" role="menu">

                    <form action="<?php echo e(route('attendances.clock', $attendance->id)); ?>" method="GET" style="display: inline-block;">

                      <button type="submit" class="btn btn-link" type="button"
                      <?php if($attendance->actual_work_time != null && $attendance->actual_home_time != null): ?>
                      disabled
                      <?php endif; ?>
                      <?php if($attendance->abnormal == false): ?>
                      disabled
                      <?php endif; ?>
                      >补打卡</button>
                    </form>

                    <form action="<?php echo e(route('attendances.addTime', $attendance->id)); ?>" method="GET" style="display: inline-block;">
                      <button type="submit" class="btn btn-link" type="button"
                      <?php if($attendance->actual_work_time == null || $attendance->should_work_time == null || $attendance->should_home_time == null || $attendance->actual_home_time == null): ?>
                      disabled
                      <?php endif; ?>
                      <?php if($attendance->abnormal == false): ?>
                      disabled
                      <?php endif; ?>
                      >补工时</button>
                    </form>
                    <br>
                    <!-- <li><a href="#">Tablet</a></li> -->
                    <form action="<?php echo e(route('attendances.createExtra', $attendance->id)); ?>" method="GET" style="display: inline-block;">
                      <button type="submit" class="btn btn-link" type="button"
                      <?php if($attendance->extra_work_id != null): ?>
                      disabled
                      <?php elseif($attendance->should_duration == null): ?>
                        <?php if(($attendance->actual_work_time == null && $attendance->actual_home_time != null) || ($attendance->actual_work_time != null && $attendance->actual_home_time == null)): ?>
                          disabled
                        <?php endif; ?>
                      <?php elseif($attendance->should_duration != null): ?>
                        <?php if($attendance->actual_work_time == null || $attendance->actual_home_time == null): ?>
                          disabled
                        <?php endif; ?>
                      <?php endif; ?>
                      >补加班</button>
                    </form>

                    <form action="<?php echo e(route('attendances.createAbsence', $attendance->id)); ?>" method="GET" style="display: inline-block;">
                      <button type="submit" class="btn btn-link" type="button"
                      <?php if($attendance->absence_id != null): ?>
                      disabled
                      <?php elseif($attendance->should_duration == null): ?>
                      disabled
                      <?php endif; ?>
                      <?php if($attendance->should_duration != null): ?>
                        <?php if(($attendance->actual_work_time == null && $attendance->actual_home_time != null) || ($attendance->actual_work_time != null && $attendance->actual_home_time == null)): ?>
                          disabled
                        <?php endif; ?>
                      <?php elseif($attendance->abnormal == false): ?>
                      disabled
                      <?php endif; ?>
                      >补请假</button>
                    </form>
                  </ul>
                </div>

                <form action="<?php echo e(route('attendances.basic',$attendance->id)); ?>" method="GET" style="display: inline-block; margin: 4px;">
                  <?php echo e(csrf_field()); ?>

                  <button type="submit" class="btn btn-info" type="button"
                  <?php if($attendance->basic_duration == null): ?>
                  disabled
                  <?php endif; ?>
                  >更改基本工时</button>
                </form>
            </td>
        </tr>
      <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</table>

<div style="margin: 20px">
  <a class="btn btn-primary" href="<?php echo e(route('attendances.results',array('year'=>$year,'month'=>$month))); ?>" role="button">返回考勤汇总</a>
  <a class="btn btn-primary" href="<?php echo e(route('attendances.results')); ?>" role="button">返回查询界面</a>
</div>

<script>

  function delcfm() {
      if (!confirm("确认操作？")) {
          window.event.returnValue = false;
      }
  }

</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.default', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\lsh\Desktop\finall-design\20241119\attendance-system-master\resources\views/attendances/show.blade.php ENDPATH**/ ?>