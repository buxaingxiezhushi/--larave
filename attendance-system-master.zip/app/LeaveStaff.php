<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class LeaveStaff extends Model
{
    //
}
