<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class AttendanceMidTable extends Model
{
    //
}
