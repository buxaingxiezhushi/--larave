<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Attendance;
use App\Staff;
use App\Holiday;
use App\ExtraWork;
use App\Absence;
use App\TotalAttendance;
use App\AddTime;
use App\AbnormalNote;
use Illuminate\Support\Facades\Storage;
use PhpOffice\PhpSpreadsheet\Spreadsheet;
use PhpOffice\PhpSpreadsheet\Style\Alignment;
use PhpOffice\PhpSpreadsheet\Reader\Xlsx;
use PhpOffice\PhpSpreadsheet\Reader\Xls;
use PhpOffice\PhpSpreadsheet\Writer;
use PhpOffice\PhpSpreadsheet\IOFactory;
use PhpOffice\PhpSpreadsheet\Cell\Coordinate;
use Illuminate\Support\Carbon;

class AttendancesController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
        $this->tolerance = 5;
    }

    public function deleteAll()
{
    // 删除 total_attendances 表中的所有记录
    TotalAttendance::truncate();

    // 提示用户操作成功
    session()->flash('success', '所有考勤记录已成功删除！');

    // 重定向到考勤管理页面
    return redirect()->route('attendances.index');
}


    public function index(Request $request)
    {
       // 如果用户提交了月份和年份
    if ($request->get('month') != null && $request->get('year') != null)
    {
        // 获取年份和月份
        $year = $request->get('year');
        $month = $request->get('month');

        // 如果用户选择了员工
        if ($request->get('staff_id') != null)
        {
            $staff_id = $request->get('staff_id');

            // 查询TotalAttendance数据
            $total_attendances = TotalAttendance::where('staff_id', $staff_id)
                                                 ->where('year', $year)
                                                 ->where('month', $month)
                                                 ->orderBy('staff_id', 'asc')
                                                 ->get();

            // 如果没有查询到数据，插入考勤记录
            if (count($total_attendances) == 0)
            {
                // 获取员工的部门和职位信息
                $staff = Staff::find($staff_id);
                $department_id = $staff->department_id;
                $position_id = $staff->position_id;

                // 计算应该工作时长（should_duration）等字段的总和
                $should_duration_sum = Attendance::where('staff_id', $staff_id)
                                                  ->whereYear('date', $year)
                                                  ->whereMonth('date', $month)
                                                  ->sum('should_duration');

                $actual_duration_sum = Attendance::where('staff_id', $staff_id)
                                                  ->whereYear('date', $year)
                                                  ->whereMonth('date', $month)
                                                  ->sum('actual_duration');

                $basic_duration_sum = Attendance::where('staff_id', $staff_id)
                                                 ->whereYear('date', $year)
                                                 ->whereMonth('date', $month)
                                                 ->sum('basic_duration');

                $absence_duration_sum = Attendance::where('staff_id', $staff_id)
                                                   ->whereYear('date', $year)
                                                   ->whereMonth('date', $month)
                                                   ->sum('absence_duration');

                $add_duration_sum = Attendance::where('staff_id', $staff_id)
                                              ->whereYear('date', $year)
                                              ->whereMonth('date', $month)
                                              ->sum('add_duration');

                // 统计迟到和早到次数
                $total_late = Attendance::where('staff_id', $staff_id)
                                        ->whereYear('date', $year)
                                        ->whereMonth('date', $month)
                                        ->where('is_late', 1)
                                        ->count();

                $total_early = Attendance::where('staff_id', $staff_id)
                                         ->whereYear('date', $year)
                                         ->whereMonth('date', $month)
                                         ->where('is_early', 1)
                                         ->count();

                // 计算应该出勤的天数 (排除周六和周日)
                $should_attend_days = \Carbon\Carbon::parse("$year-$month-01")
                                                     ->daysInMonth;

                $should_attend = collect(range(1, $should_attend_days))->filter(function ($day) use ($year, $month) {
                    $date = \Carbon\Carbon::create($year, $month, $day);
                    return !$date->isWeekend(); // 排除周末
                })->count();

                // 计算实际出勤次数
                $actual_attend = Attendance::where('staff_id', $staff_id)
                                           ->whereYear('date', $year)
                                           ->whereMonth('date', $month)
                                           ->count();

                // 创建记录到total_attendances表
                TotalAttendance::create([
                    'staff_id' => $staff_id,
                    'year' => $year,
                    'month' => $month,
                    'department_id' => $department_id,
                    'position_id' => $position_id,
                    'total_should_duration' => $should_duration_sum,
                    'total_actual_duration' => $actual_duration_sum,
                    'total_basic_duration' => $basic_duration_sum,
                    'total_absence_duration' => $absence_duration_sum,
                    'total_extra_work_duration' => $add_duration_sum,
                    'total_more_extra_work_duration' => 0,  // 默认值
                    'total_lieu_work_duration' => 0,  // 默认值
                    'total_more_duration' => 0,  // 默认值
                    'total_add_duration' => 0,  // 默认值
                    'total_salary_work_duration' => $actual_duration_sum,  // 等于实际时长
                    'total_late_work' => $total_late,  // 迟到次数
                    'total_is_early' => $total_early,  // 早到次数
                    'difference' => 0,  // 默认值
                    'abnormal' => 0,  // 默认值
                    'should_attend' => $should_attend,  // 应出勤天数
                    'actual_attend' => $actual_attend,  // 实际出勤天数
                    'salary' => 0,  // 默认值
                ]);

                // 提示用户记录已插入
                session()->flash('success', '考勤记录已统计成功请再次点击查询查看！');
                return redirect()->back()->withInput();
            }
        }
        else
        {
            // 如果没有选择员工，查询所有员工在该年月的考勤记录
            $total_attendances = TotalAttendance::where('year', $year)
                                                 ->where('month', $month)
                                                 ->orderBy('department_id', 'asc')
                                                 ->get();

            // 如果没有查询到数据，插入记录
            if (count($total_attendances) == 0)
            {
                // 插入到attendance_mid_table（不指定staff_id）
                AttendanceMidTable::create([
                    'staff_id' => null, // 没有选择员工，staff_id为空
                    'year' => $year,
                    'month' => $month,
                ]);

                // 插入到total_attendances表（不指定staff_id）
                TotalAttendance::create([
                    'staff_id' => null,  // 如果没有选择员工，staff_id为空
                    'year' => $year,
                    'month' => $month,
                    'department_id' => null,  // 部门ID为空
                    'position_id' => null,    // 职位ID为空
                    'total_should_duration' => 0,
                    'total_actual_duration' => 0,
                    'total_basic_duration' => 0,
                    'total_absence_duration' => 0,
                    'total_extra_work_duration' => 0,
                    'total_more_extra_work_duration' => 0,  // 默认值
                    'total_lieu_work_duration' => 0,  // 默认值
                    'total_more_duration' => 0,  // 默认值
                    'total_add_duration' => 0,  // 默认值
                    'total_salary_work_duration' => 0,  // 默认值
                    'total_late_work' => 0,  // 迟到次数
                    'total_is_early' => 0,  // 早到次数
                    'difference' => 0,  // 默认值
                    'abnormal' => 0,  // 默认值
                    'should_attend' => 0,  // 应出勤天数
                    'actual_attend' => 0,  // 实际出勤天数
                    'salary' => 0,  // 默认值
                ]);

                // 提示用户记录已插入
                session()->flash('success', '考勤记录已插入。');
                return redirect()->back()->withInput();
            }
        }

        // 如果查询到了数据，展示查询结果
        return view('attendances/results', compact('total_attendances', 'year', 'month', 'staff_id'));
    }
    else
    {
        // 如果没有提交年份和月份，加载员工选择页面
        $staffs = Staff::all();
        return view('attendances/index', compact('staffs'));
    }

    }

    public function show(Request $request, $id)
    {
        // $month = $request->get('month');
        // $year = $request->get('year');
        $total_attendance = TotalAttendance::find($id); // 这个show的id是属于total attendance的，不是staff!!!
        $month = $total_attendance->month;
        $year = $total_attendance->year;
        $staff = $total_attendance->staff;
        // $attendances = $total_attendance->attendances;
        $attendances = Attendance::where('total_attendance_id',$total_attendance->id)->orderBy('date','asc')->get();
        return view('attendances.show',compact('staff','attendances','month','year'));
    }


    public function createExtra($id)
    {
        $attendance = Attendance::find($id);
        $total_attendance = $attendance->totalAttendance;
        $staff = Staff::find($attendance->staff_id);
        $year = $attendance->year;
        $month = $attendance->month;
        $date = $attendance->date;
        $staffs = null;
        return view('extra_works/create',compact('staffs','staff','year','month','date','attendance','total_attendance'));
    }

    public function createAbsence($id)
    {
        $attendance = Attendance::find($id);
        $total_attendance = $attendance->totalAttendance;
        $staff = Staff::find($attendance->staff_id);
        $year = $attendance->year;
        $month = $attendance->month;
        $date = $attendance->date;
        $staffs = null;
        return view('absences/create',compact('staffs','staff','year','month','date','attendance','total_attendance'));
    }

    public function changeAbnormal($id)
    {
        $attendance = Attendance::find($id);

        // if ($attendance->abnormalNote == null)
        // {
        //     session()->flash('warning','请在添加备注后修改异常');
        //     return redirect()->back();
        // }
        // else
        // {
            if ($attendance->abnormal == true)
            {
                $attendance->abnormal = false;
            }
            else
            {
                $attendance->abnormal = true;
            }
        // }

        if ($attendance->save())
        {
            $this_month_attendances = $attendance->totalAttendance->attendances;
            // 查一下还有没有异常
            $this_month_abnormal = $this_month_attendances->where('abnormal',true);
            if (count($this_month_abnormal) == 0)
            {
                // 如果没有异常返回 false
                $attendance->totalAttendance->abnormal = false;
            }
            else
            {
                $attendance->totalAttendance->abnormal = true;
            }
            $attendance->totalAttendance->save();
            session()->flash('success','更改'.$attendance->month.'月'.$attendance->date.'日异常成功！');
            return redirect()->back();
        }
    }

    public function addNote($id)
    {
        $attendance = Attendance::find($id);
        $total_attendance = $attendance->totalAttendance;
        $month = $attendance->month;
        $year = $attendance->year;
        return view('attendances.add_note',compact('attendance','total_attendance','month','year'));
    }

    public function createAddNote($id, Request $request)
    {
        $attendance = Attendance::find($id);
        $total_attendance = $attendance->totalAttendance;
        $this->validate($request, [
        'note'=>'required|max:140',
        ]);
        $abnormal_note = new AbnormalNote();
        $abnormal_note->note = $request->get('note');
        $abnormal_note->attendance_id = $attendance->id;
        $month = $attendance->month;
        $year = $attendance->year;
        if ($abnormal_note->save())
        {
            session()->flash('success', '异常备注添加成功！');
            return redirect()->route('attendances.show',array($total_attendance->id,'month'=>$month,'year'=>$year));
        }
    }

    public function addTime($id)
    {
        $attendance = Attendance::find($id);
        $month = $attendance->month;
        $year = $attendance->year;
        $total_attendance = $attendance->totalAttendance;
        // 最多支持添加两段增补记录，一首一尾，以便解决更新是否迟到早退的问题。
        $all_add_times = count($attendance->addTimes);

        if ($all_add_times >= 2)
        {
            session()->flash('warning', '最多支持两段增补记录！');
            return redirect()->back();
        }
        else
        {
            return view('attendances.add_time',compact('attendance','total_attendance','month','year'));
        }
    }

    // 增补时间：一般是因为某些原因，实际时长少了，需要增加时长来补足空缺。主要适用于因合理原因迟到早退的情况：如地铁故障，哺乳期等
    // 原来的实际时间+请假时间-加班时间+增补的时间如果大于等于应该的时间，那么就不异常了。（前提是存在应该的时间）
    // 增补工时的目的是为了消除迟到早退次数，如果迟到早退本来就没有数据，那么是无法增补工时的。
    public function createAddTime(Request $request, $id)
    {
        $this->validate($request, [
            'add_start_time'=>'required',
            'add_end_time'=>'required',
            'reason'=>'required',
        ]);

        $attendance = Attendance::find($id);
        $total_attendance = $attendance->totalAttendance;

        $add_time = new AddTime();
        $add_start_time = $request->get('add_start_time');
        $add_end_time = $request->get('add_end_time');

        $y_m_d = $attendance->year.'-'.$attendance->month.'-'.$attendance->date;
        $str_add_start_time = strtotime($y_m_d.' '.$add_start_time);
        $str_add_end_time = strtotime($y_m_d.' '.$add_end_time);

        // 检测时间填写是否正确
        if ($add_start_time == null || $add_end_time == null)
        {
            session()->flash('warning','时间填写不完整！');
            return redirect()->back()->withInput();
        }

        if (strtotime($add_start_time)>strtotime($add_end_time))
        {
            session()->flash('warning','开始时间晚于结束时间！');
            return redirect()->back()->withInput();
        }

        if ($attendance->actual_work_time != null && $attendance->actual_home_time!=null)
        {
            $actual_work_time = strtotime($y_m_d.' '.$attendance->actual_work_time);

            $actual_home_time = strtotime($y_m_d.' '.$attendance->actual_home_time);
            // 不能和上班时间重合
            if ($add_time->isCrossing($str_add_start_time, $str_add_end_time, $actual_work_time, $actual_home_time))
            {
                session()->flash('warning','时间与上班时间重叠！');
                return redirect()->back()->withInput();
            }
        }

        if ($attendance->extraWork != null && $attendance->extraWork!=null)
        {
            $extra_work_start_time = strtotime($attendance->extraWork->extra_work_start_time);
            $extra_work_end_time = strtotime($attendance->extraWork->extra_work_end_time);
            // 不能和加班时间重合
            if ($add_time->isCrossing($str_add_start_time, $str_add_end_time, $extra_work_start_time, $extra_work_end_time))
            {
                session()->flash('warning','时间与加班时间重叠！');
                return redirect()->back()->withInput();
            }
        }

        if ($attendance->absence != null && $attendance->absence!=null)
        {
            $absence_start_time = strtotime($attendance->absence->absence_start_time);
            $absence_end_time = strtotime($attendance->absence->absence_end_time);
            // 不能和请假时间重合
            if ($add_time->isCrossing($str_add_start_time, $str_add_end_time, $absence_start_time, $absence_end_time))
            {
                session()->flash('warning','时间与请假时间重叠！');
                return redirect()->back()->withInput();
            }
        }
        $reason = $request->get('reason');

        $add_time->attendance_id = $attendance->id;
        $add_time->add_start_time = $add_start_time;
        $add_time->add_end_time = $add_end_time;

        // 要判断是否与存在的记录重合
        $add_times = $attendance->addTimes; // 取出所有增补记录
        foreach ($add_times as $at) {
            $old_start_time = $at->add_start_time;
            $old_end_time = $at->add_end_time;
            if($add_time->isCrossing($add_start_time, $add_end_time, $old_start_time, $old_end_time))
            {
                session()->flash('warning','时间与已有记录重叠！');
                return redirect()->back()->withInput();
            }
        }

        $add_time->duration = $add_time->calDuration($add_start_time, $add_end_time);
        $add_time->reason = $reason;

        if ($add_time->save())
        {
            // 添加完增补时间之后，需要对这一条考勤重新计算是否异常
            // 先把所有增补时间都加起来
            $total_add = 0;
            $attendance = Attendance::find($attendance->id);
            $add_times = $attendance->addTimes;
            if (count($add_times) == 0)
            {
                $total_add = $add_time->duration;
            }
            else
            {
                foreach($add_times as $at)
                {
                    $total_add += $at->duration;
                }
            }

            $attendance->add_duration = $total_add;

            // 计算这一条attendance是否异常
            Attendance::isAbnormal($attendance);
            // 理论上上条保存的 abnormal 后面会更新。
            if ($attendance->abnormal != false)
            {
                $work = strtotime($attendance->should_work_time);
                $home = strtotime($attendance->should_home_time);
                // 先把这两段时间取出来
                foreach ($add_times as $at)
                {
                    $start = strtotime($at->add_start_time);
                    $end = strtotime($at->add_end_time);

                    // 判断开始、结束时间距离上下班哪个时间近，由此判断是该修改迟到还是早退。
                    $judge_late = abs($start-$work);
                    $judge_early = abs($home-$end);

                    if ($judge_late <= $judge_early) // 开始时间离上班时间近，所以用这个时间判断是否早退
                    { // 由于调用的函数里有 should 和 actual, 此处以1和0代替，以满足条件

                        $late_work = ($start-$work)/60; // 转换成分钟
                        $attendance->is_late = Attendance::lateOrEarly($late_work, 1, 0, $attendance->is_late);
                    }
                    else
                    {
                        $early_home = ($home-$end)/60;
                        $attendance->is_early = Attendance::lateOrEarly($early_home, 1, 0, $attendance->is_late);
                    }
                }
            }
            // }

            $month = $attendance->month;
            $year = $attendance->year;
            if ($attendance->save())
            {
                // 这条记录保存之后，判断该月记录是否仍然异常
                $this_month_attendances = $attendance->totalAttendance->attendances;
                TotalAttendance::updateTotal($this_month_attendances, $attendance);
                return redirect()->route('attendances.show',array($total_attendance->id,'month'=>$month,'year'=>$year));
            }
        }
    }

    public function clock($id)
    {
        $attendance = Attendance::find($id);
        $month = $attendance->month;
        $year = $attendance->year;
        $total_attendance = $attendance->totalAttendance;
        return view('attendances.clock',compact('attendance','total_attendance','month','year'));
    }

    public function updateClock(Request $request, $id)
    {
        $this->validate($request, [
            'actual_work_time'=>'required',
            'actual_home_time'=>'required',
        ]);
        $attendance = Attendance::find($id);
        $total_attendance = $attendance->totalAttendance;
        $attendance->actual_home_time = $request->get('actual_home_time');
        $attendance->actual_work_time = $request->get('actual_work_time');

        // 检测时间填写是否正确
        if ($attendance->actual_home_time == null || $attendance->actual_work_time == null)
        {
            session()->flash('warning','时间填写不完整！');
            return redirect()->back()->withInput();
        }

        if (strtotime($attendance->actual_work_time)>strtotime($attendance->actual_home_time))
        {
            session()->flash('warning','上班时间晚于下班时间！');
            return redirect()->back()->withInput();
        }

        if ($attendance->should_work_time != null && $attendance->should_home_time != null) {
            $swt = strtotime($attendance->should_work_time);
            $sht = strtotime($attendance->should_home_time);
            $attendance->should_duration = $attendance->calDuration($swt,$sht);
        }
        if ($attendance->actual_work_time != null && $attendance->actual_home_time != null)
        {
            $awt = strtotime($attendance->actual_work_time);
            $aht = strtotime($attendance->actual_home_time);
            $attendance->actual_duration = $attendance->calDuration($awt,$aht);
        }

        if ($attendance->should_work_time != null && $attendance->should_home_time != null)
        {
            $attendance->late_work = ($awt-$swt)/60; // 转换成分钟
            $attendance->is_late = Attendance::lateOrEarly($attendance->late_work, $attendance->should_duration, $attendance->actual_duration, $is_late_early = false);
            $attendance->early_home = ($sht-$aht)/60;
            $attendance->is_early = Attendance::lateOrEarly($attendance->early_home, $attendance->should_duration, $attendance->actual_duration, $is_late_early = false);
        }
        // 计算这一条attendance是否异常
        Attendance::isAbnormal($attendance);
        Attendance::calBasic($attendance, $attendance->extra_work_id);
        $month = $attendance->month;
        $year = $attendance->year;

        if ($attendance->save())
        {
            // 这条记录保存之后，判断该月记录是否仍然异常
            $this_month_attendances = $attendance->totalAttendance->attendances;
            TotalAttendance::updateTotal($this_month_attendances, $attendance, $type='clock');
            return redirect()->route('attendances.show',array($total_attendance->id,'month'=>$month, 'year'=>$year));
        }
        // }
        // else
        // {
        //     session()->flash('danger','该日期不异常，无法进行补打卡！');
        //     return redirect()->back()->withInput();
        // }

    }

    /**
     * 将上传的表格导入数据库并进行汇总计算 -- 这是这个考勤系统的最终目标
     *
     *
     */
    public function import(Request $request)
    {
        // 检查是否上传文件
    if ($request->hasFile('select_file')) {
        $file = $request->file('select_file');
        \Log::info('上传文件信息', [
            '原始文件名' => $file->getClientOriginalName(),
            '扩展名' => $file->getClientOriginalExtension(),
            'MIME 类型' => $file->getMimeType(),
            '临时路径' => $file->getRealPath(),
        ]);
    }

    // 验证上传文件的格式和大小
    $this->validate($request, [
        'select_file' => 'required|file|max:20480',
    ], [
        'select_file.required' => '请选择一个文件进行上传！',
        'select_file.max' => '文件大小不能超过 20MB。',
    ]);

    if ($request->isMethod('POST')) {
        $file = $request->file('select_file');

        // 检查文件是否上传成功
        if ($file->isValid()) {
            $mimeType = $file->getMimeType();
            $ext = strtolower($file->getClientOriginalExtension());
            $originalName = $file->getClientOriginalName();
            $realPath = $file->getRealPath(); // 临时路径

            // 日志记录文件信息，方便调试
            \Log::info('上传文件信息', [
                '原始文件名' => $originalName,
                '扩展名' => $ext,
                'MIME 类型' => $mimeType,
                '临时路径' => $realPath,
            ]);

            // 检查扩展名是否合法
            if (!in_array($ext, ['xls', 'xlsx'])) {
                session()->flash('danger', "文件扩展名错误，仅支持 .xls 和 .xlsx 文件。实际扩展名：$ext");
                return redirect()->back();
            }

            // 检查 MIME 类型是否合法，同时允许 application/octet-stream
            $allowedMimeTypes = [
                'application/vnd.ms-excel',
                'application/vnd.openxmlformats-officedocument.spreadsheetml.sheet',
                'application/octet-stream' // 允许 octet-stream 类型
            ];
            if (!in_array($mimeType, $allowedMimeTypes)) {
                session()->flash('danger', "文件 MIME 类型错误，仅支持 .xls 和 .xlsx 文件。实际 MIME 类型：$mimeType");
                return redirect()->back();
            }

            // 根据扩展名选择文件读取器
            $reader = null;
            if ($ext === 'xlsx') {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xlsx();
            } elseif ($ext === 'xls') {
                $reader = new \PhpOffice\PhpSpreadsheet\Reader\Xls();
            } else {
                session()->flash('danger', '文件格式错误，仅支持 .xls 和 .xlsx 文件。');
                return redirect()->back();
            }

            $reader->setReadDataOnly(true);

            try {
                // 加载表格数据
                $spreadsheet = $reader->load($realPath);
                $worksheet = $spreadsheet->getActiveSheet();
                $highestRow = $worksheet->getHighestRow(); // 获取总行数

                // 定义星期几的映射关系
                $weekDayMap = [
                    '一' => 1, // Monday
                    '二' => 2, // Tuesday
                    '三' => 3, // Wednesday
                    '四' => 4, // Thursday
                    '五' => 5, // Friday
                    '六' => 6, // Saturday
                    '日' => 0, // Sunday
                ];

                // 从第三行开始读取数据
                for ($row = 3; $row <= $highestRow; $row++) {
                    $employeeName = $worksheet->getCellByColumnAndRow(1, $row)->getValue();
                    $employeeId = $worksheet->getCellByColumnAndRow(2, $row)->getValue();
                    $date = $worksheet->getCellByColumnAndRow(3, $row)->getValue();
                    $clockIn = $worksheet->getCellByColumnAndRow(4, $row)->getValue(); // 上班打卡
                    $clockOut = $worksheet->getCellByColumnAndRow(5, $row)->getValue(); // 下班打卡

                    // 跳过空行
                    if (empty($employeeName) || empty($employeeId) || empty($date)) {
                        continue;
                    }

                    // 转换日期
                    $dateObject = \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($date);
                    $formattedDate = $dateObject->format('Y-m-d');
                    $weekDay = $dateObject->format('w'); // 获取星期几 (0: 周日, 6: 周六)

                    // 处理打卡时间：转换为 `H:i:s` 格式
                    $formattedClockIn = $clockIn ? \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($clockIn)->format('H:i:s') : null;
                    $formattedClockOut = $clockOut ? \PhpOffice\PhpSpreadsheet\Shared\Date::excelToDateTimeObject($clockOut)->format('H:i:s') : null;

                    // 查找员工信息
                    $staff = Staff::where('id', $employeeId)->orWhere('staffname', $employeeName)->first();
                    if (!$staff) {
                        session()->flash('danger', '员工信息未找到: ' . $employeeName);
                        continue;
                    }

                    // 查找节假日类型
                    $holiday = \App\Holiday::where('date', $formattedDate)->first();
                    if ($holiday) {
                        $workdayType = $holiday->holiday_type; // 如果是节假日，使用 holidays 表中的 holiday_type
                    } else {
                        // 如果不是节假日，判断星期几
                        if ($weekDay == 0 || $weekDay == 6) {
                            $workdayType = '休息日'; // 星期六和星期天为休息日
                        } else {
                            $workdayType = '工作日'; // 星期一到星期五为工作日
                        }
                    }

                    // 查找员工的工作日数据
                    $staffWorkday = \App\StaffWorkday::where('staff_id', $staff->id)
                        ->where('workday_name', array_search($weekDay, $weekDayMap))
                        ->first(); // 找到符合条件的工作日记录

                    if (!$staffWorkday) {
                        session()->flash('danger', '员工 ID: ' . $staff->id . ' 没有对应的工作日数据');
                        continue;
                    }

                    // 获取工作时间和下班时间
                    $shouldWorkTime = $staffWorkday->work_time;  // 默认工作时间
                    $shouldHomeTime = $staffWorkday->home_time; // 默认下班时间

                    // 查找应出勤时长
                    $shouldDuration = $staffWorkday->duration ?? 8;  // 默认8小时

                    // 计算迟到和早退
                    $lateWork = 0;
                    $isLate = 0;
                    if (!empty($shouldWorkTime) && !empty($formattedClockIn)) {
                        $shouldWorkTimeTimestamp = strtotime($shouldWorkTime);
                        $actualWorkTimeTimestamp = strtotime($formattedClockIn);

                        if ($actualWorkTimeTimestamp > $shouldWorkTimeTimestamp) {
                            $lateWork = round(($actualWorkTimeTimestamp - $shouldWorkTimeTimestamp) / 60); // 计算迟到分钟数
                            $isLate = 1; // 标记为迟到
                        }
                    }

                    // 计算早退
                    $earlyHome = 0;
                    $isEarly = 0;
                    if (!empty($shouldHomeTime) && !empty($formattedClockOut)) {
                        $shouldHomeTimeTimestamp = strtotime($shouldHomeTime);
                        $actualHomeTimeTimestamp = strtotime($formattedClockOut);

                        if ($actualHomeTimeTimestamp < $shouldHomeTimeTimestamp) {
                            $earlyHome = round(($shouldHomeTimeTimestamp - $actualHomeTimeTimestamp) / 60); // 计算早退分钟数
                            $isEarly = 1; // 标记为早退
                        }
                    }

                    // 计算实际工作时长
                    $actualDuration = 0;
                    if (!empty($formattedClockIn) && !empty($formattedClockOut)) {
                        $actualWorkTimeTimestamp = strtotime($formattedClockIn);
                        $actualHomeTimeTimestamp = strtotime($formattedClockOut);

                        $actualDuration = round(($actualHomeTimeTimestamp - $actualWorkTimeTimestamp) / 3600, 2); // 转为小时，保留两位小数
                    }

                    // 计算基本工时
                    $basicDuration = $actualDuration < 8.00 ? $actualDuration : 8.00;

                    // 查找加班时长
                    $extraWork = \App\ExtraWork::where('staff_id', $staff->id)
                        ->where('extra_work_start_time', '<=', $formattedDate)
                        ->where('extra_work_end_time', '>=', $formattedDate)
                        ->where('approve', 1) // 检查是否批准
                        ->first();

                    $addDuration = $extraWork ? $extraWork->duration : 0;

                    // 查找缺勤记录
                    $absence = \App\Absence::where('staff_id', $staff->id)->first();
                    $absenceId = $absence ? $absence->id : null;
                    $absenceDuration = $absence ? $absence->duration : 0; // 如果没有缺勤，则设置为 0
                    $absenceType = $absence ? $absence->absence_type : null;

                    // 计算异常
                    $abnormal = 1; // 默认异常
                    if ($actualDuration + $addDuration - $absenceDuration >= $shouldDuration) {
                        $abnormal = 0; // 不异常
                    }

                    // 检查是否已存在考勤记录
                    $attendance = Attendance::where('staff_id', $staff->id)
                        ->where('year', $dateObject->format('Y'))
                        ->where('month', $dateObject->format('m'))
                        ->where('day', $dateObject->format('d'))
                        ->first();

                    // 创建新的考勤记录
                    Attendance::create([
                        'staff_id' => $staff->id,
                        'year' => $dateObject->format('Y'),
                        'month' => $dateObject->format('m'),
                        'day' => $dateObject->format('d'),
                        'date' => $formattedDate,
                        'workday_type' => $workdayType,
                        'should_work_time' => $shouldWorkTime,
                        'should_home_time' => $shouldHomeTime,
                        'should_duration' => $shouldDuration,
                        'actual_work_time' => $formattedClockIn,  // 上班打卡时间存入字段
                        'actual_home_time' => $formattedClockOut, // 下班打卡时间存入字段
                        'is_late' => $isLate,
                        'late_work' => $lateWork,  // 这里修改为 `late_work`
                        'is_early' => $isEarly,
                        'early_home' => $earlyHome, // 这里修改为 `early_home`
                        'actual_duration' => $actualDuration,
                        'basic_duration' => $basicDuration,
                        'add_duration' => $addDuration,
                        'absence_id' => $absenceId,
                        'absence_duration' => $absenceDuration,
                        'absence_type' => $absenceType,
                        'abnormal' => $abnormal,
                    ]);
                }
            } catch (\PhpOffice\PhpSpreadsheet\Exception $e) {
                session()->flash('danger', '文件处理失败，请检查文件格式！');
                return redirect()->back();
            }
        } else {
            session()->flash('danger', '文件上传失败，请重试！');
            return redirect()->back();
        }
    }

    session()->flash('success', '文件导入成功！');
    return redirect()->back();
    }

    public function export(Request $request)
    {
        // $staff_id = $request->input('staff_id');
        $year = $request->input('year');
        $month = $request->input('month');
        $option = $request->input('option');
        $spreadsheet = new Spreadsheet();
        TotalAttendance::exportTotal($spreadsheet, $year, $month, $option);
    }

    public function basic($id)
    {
        $attendance = Attendance::find($id);
        $month = $attendance->month;
        $year = $attendance->year;
        $total_attendance = $attendance->totalAttendance;
        return view('attendances.change_basic',compact('attendance','total_attendance','month','year'));
    }

        public function changeBasic($id, Request $request)
    {
        // 更改基本工时，对是否异常没有影响。
        $this->validate($request, [
            'basic_duration'=>'required|numeric',
        ]);
        // 对这一条考勤进行更改
        $attendance = Attendance::find($id);
        $total_attendance = $attendance->totalAttendance;
        $old_duration = $attendance->basic_duration;
        $new_duration = $request->get('basic_duration');
        $attendance->basic_duration = $new_duration;
        if ($attendance->save())
        {
            // 总记录上总基本时间更新
            $total_attendance->total_basic_duration = $total_attendance->total_basic_duration + ($new_duration-$old_duration);
            $total_attendance->difference = $total_attendance->total_basic_duration - $total_attendance->total_should_duration;
            $total_attendance->save();
            $month = $attendance->month;
            $year = $attendance->year;
            session()->flash('success','基本工时修改成功！');
            return redirect()->route('attendances.show',array($total_attendance->id,'month'=>$month,'year'=>$year));
        }
        else
        {
            session()->flash('danger','基本工时修改失败！');
            return redirect()->back()->withInput();
        }
    }
}
